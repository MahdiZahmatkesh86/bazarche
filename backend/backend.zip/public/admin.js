(()=>{
'use strict';

/* Global asset URL resolver */
(function(){
  try{
    var api = (typeof API !== 'undefined') ? API : 'http://127.0.0.1:5000/api';
    window.__BACKEND__ = api.replace(/\/api\/?$/, '');
  }catch(e){ window.__BACKEND__ = 'http://127.0.0.1:5000'; }
  window.__ASSET__ = function(u){
    if(!u) return '';
    u = String(u);
    if(/^https?:\/\//i.test(u) || /^data:/i.test(u)) return u;
    var origin = window.__BACKEND__ || 'http://127.0.0.1:5000';
    if(u.charAt(0) === '/') return origin + u;
    return origin + '/' + u;
  };
})();


const API = '/api';





/* ================================================================
   GLOBAL ASSET RESOLVER — for /uploads/ images
   ================================================================ */
(function(){
  "use strict";
  /* figure out the backend origin */
  var origin = "http://127.0.0.1:5000";
  try{
    /* try to read from API constant that is already defined in this scope */
    if(typeof API !== "undefined" && API){
      origin = String(API).replace(/\/api\/?$/, "");
    }else if(window.__API_BASE){
      origin = String(window.__API_BASE).replace(/\/api\/?$/, "");
    }else if(window.__BACKEND_ORIGIN__){
      origin = window.__BACKEND_ORIGIN__;
    }
  }catch(e){}
  window.__BACKEND_ORIGIN__ = origin;

  window.__ASSET__ = function(u){
    if(!u) return "";
    u = String(u);
    if(/^https?:\/\//i.test(u)) return u;
    if(/^data:/i.test(u)) return u;
    if(/^blob:/i.test(u)) return u;
    var o = window.__BACKEND_ORIGIN__ || origin;
    if(u.charAt(0) === "/") return o + u;
    return o + "/" + u;
  };

  console.log("[asset] origin =", origin);
})();

window.__BACKEND_ORIGIN__ = 'http://127.0.0.1:5000';
window.__resolveCardImg = function(p){
  if(!p) return null;
  var imgs = p.images || null;
  if(Array.isArray(imgs) && imgs.length){
    var u = imgs[0];
    if(!u) return null;
    if(/^https?:\/\//i.test(u)) return u;
    var o = window.__BACKEND_ORIGIN__ || '';
    return u.charAt(0) === '/' ? o + u : o + '/' + u;
  }
  return null;
};
/* Force backend origin for /uploads/ images */
(function(){
  var origin = API.replace(/\/api$/, '');
  window.__BACKEND_ORIGIN__ = origin;
  console.log('[fixup] backend origin =', origin);
})();
window.__API_BASE = API;
/* __UPLOAD_HELPERS__ */
const API_ORIGIN = API.replace('/api','');
function toAbsUrl(u){ return window.__ASSET__ ? window.__ASSET__(u) : u; }
async function uploadProductImage(file, onProgress){
  const fd = new FormData();
  fd.append('image', file);
  return new Promise(function(resolve, reject){
    const xhr = new XMLHttpRequest();
    xhr.open('POST', API + '/upload/product-single', true);
    xhr.withCredentials = true;
    if(onProgress) xhr.upload.onprogress = function(e){
      if(e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100));
    };
    xhr.onload = function(){
      try{
        const r = JSON.parse(xhr.responseText || '{}');
        if(xhr.status >= 200 && xhr.status < 300 && r.success) resolve(r.url);
        else reject(new Error(r.message || ('HTTP ' + xhr.status)));
      }catch(e){ reject(e); }
    };
    xhr.onerror = function(){ reject(new Error('خطای شبکه')); };
    xhr.send(fd);
  });
}

/* __GLOBAL_UPLOAD_HANDLER__ */
(function setupGlobalUpload(){
  'use strict';

  /* single hidden input created once */
  let picker = document.getElementById('__globalImgPicker');
  if(!picker){
    picker = document.createElement('input');
    picker.type = 'file';
    picker.id = '__globalImgPicker';
    picker.accept = 'image/*';
    picker.multiple = true;
    picker.style.position = 'fixed';
    picker.style.left = '-9999px';
    picker.style.top = '-9999px';
    picker.style.opacity = '0';
    document.body.appendChild(picker);
  }

  let currentTarget = null;    /* element that opened the picker */
  let currentFRef = null;      /* the F object of the open form */
  let currentRepaint = null;   /* repaint function to call */
  let currentToastArea = null;

  /* listen for clicks anywhere */
  document.addEventListener('click', function(e){
    const btn = e.target.closest && e.target.closest('#uploadImgBtn');
    if(!btn) return;
    e.preventDefault();
    e.stopPropagation();
    currentTarget = btn;

    /* find the F object + repaint function from the modal */
    currentFRef = window.__activeProductF || null;
    currentRepaint = window.__activeProductRepaint || null;

    if(!currentFRef){
      console.warn('[upload] no active product F reference');
    }

    picker.value = '';
    picker.click();
  }, true /* capture */);

  /* file selection */
  picker.addEventListener('change', async function(){
    const files = Array.from(picker.files || []);
    if(!files.length) return;

    if(!currentFRef){
      try{ toast('ابتدا فرم محصول را باز کنید.', 'warn'); }catch(_){}
      picker.value = '';
      return;
    }

    /* progress UI */
    let progressEl = document.getElementById('uploadProgress');
    let bar = progressEl && progressEl.querySelector('.adm-upload-bar i');
    let lbl = progressEl && progressEl.querySelector('.adm-upload-lbl');
    if(progressEl) progressEl.hidden = false;

    let done = 0;
    const total = files.length;

    for(let i = 0; i < files.length; i++){
      const f = files[i];
      if(f.size > 5 * 1024 * 1024){
        try{ toast('«' + f.name + '» بیش از ۵ مگابایت است.', 'warn'); }catch(_){}
        done++;
        continue;
      }
      try{
        if(lbl) lbl.textContent = 'در حال آپلود ' + (done+1) + ' از ' + total + '...';
        const url = await uploadProductImage(f, function(p){
          if(bar) bar.style.width = p + '%';
        });
        if(!Array.isArray(currentFRef.images)) currentFRef.images = [];
        currentFRef.images.push(url);
        if(typeof window.__activeProductRepaint === 'function') window.__activeProductRepaint();
        done++;
      }catch(err){
        console.error('[upload] error:', err);
        try{ toast('خطا در «' + f.name + '»: ' + (err.message || 'نامشخص'), 'err', 5000); }catch(_){}
        done++;
      }
    }

    if(progressEl) progressEl.hidden = true;
    if(bar) bar.style.width = '0%';
    if(done > 0){
      try{ toast(done + ' تصویر آپلود شد. یادت نره ذخیره کنی.', 'ok', 4500); }catch(_){}
    }
    picker.value = '';
    currentFRef = null;
    currentRepaint = null;
  });
})();




/* ---------- helpers ---------- */
const $  = (s,r=document)=>r.querySelector(s);
const $$ = (s,r=document)=>[...r.querySelectorAll(s)];
const fa = n => Number(n||0).toLocaleString('fa-IR');
const esc = s => String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const toEn = s => String(s??'').replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d));
const getStore = (k,d)=>{try{const v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}};
const setStore = (k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};

/* ---------- icons ---------- */
const ICONS = {
  dashboard:'<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
  box:'<path d="M21 8v8a2 2 0 0 1-1 1.73l-7 4a2 2 0 0 1-2 0l-7-4A2 2 0 0 1 3 16V8a2 2 0 0 1 1-1.73l7-4a2 2 0 0 1 2 0l7 4A2 2 0 0 1 21 8z"/><path d="M3.27 6.96 12 12.01l8.73-5.05M12 22.08V12"/>',
  grid:'<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  cart:'<circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l2.6 12.4a2 2 0 0 0 2 1.6h7.7a2 2 0 0 0 2-1.5L21 8H6"/>',
  users:'<circle cx="9" cy="8" r="3.5"/><path d="M2 21c0-3.5 3.1-6 7-6s7 2.5 7 6"/><path d="M17 4a3.5 3.5 0 0 1 0 7M22 21c0-3-2-5.3-5-5.9"/>',
  star:'<path d="M12 3l2.7 5.5 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.8 1-6.1L3.2 9.4l6.1-.9z"/>',
  user:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>',
  menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',
  sun:'<circle cx="12" cy="12" r="4.5"/><path d="M12 2v2M12 20v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M2 12h2M20 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4"/>',
  moon:'<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
  refresh:'<path d="M21 12a9 9 0 1 1-3-6.7M21 4v6h-6"/>',
  logout:'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
  external:'<path d="M15 3h6v6M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
  chevdown:'<path d="M6 9l6 6 6-6"/>',
  search:'<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  edit:'<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.1 2.1 0 1 1 3 3L12 15l-4 1 1-4z"/>',
  trash:'<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  check:'<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  x:'<path d="M6 6l12 12M18 6L6 18"/>',
  eye:'<path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z"/><circle cx="12" cy="12" r="3"/>',
  toggleOn:'<rect x="2" y="6" width="20" height="12" rx="6" fill="currentColor"/><circle cx="17" cy="12" r="4" fill="#fff"/>',
  toggleOff:'<rect x="2" y="6" width="20" height="12" rx="6" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="7" cy="12" r="3" fill="currentColor"/>',
  wallet:'<rect x="3" y="6" width="18" height="14" rx="2"/><path d="M3 10h18M16 14h.01"/>',
  file:'<path d="M6 2h9l5 5v15H6z"/><path d="M14 2v6h6M9 13h6M9 17h4"/>',
  image:'<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="M3 15l5-5 6 6 3-3 4 4"/>',
  layers:'<path d="M12 2L2 7l10 5 10-5z"/><path d="M2 17l10 5 10-5M2 12l10 5 10-5"/>',
  
  trend:'<path d="M22 7 13.5 15.5l-5-5L2 17"/><path d="M16 7h6v6"/>'
};
const ic=(n,s=20)=>`<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[n]||''}</svg>`;

const hydrateIcons = (root=document)=>{
  $$('[data-ic]',root).forEach(e=>{
    const name=e.dataset.ic;
    if(ICONS[name]) e.innerHTML = ic(name, e.dataset.s||20).replace('<svg class="ic"','<svg');
  });
};

/* ---------- API client ---------- */
let currentUser = null;
async function api(path,opts={}){
  const res = await fetch(API+path,{
    credentials:'include',
    headers:{'Content-Type':'application/json',...(opts.headers||{})},
    ...opts
  });
  let data = null;
  try{ data = await res.json(); }catch(e){ data = { success:false, message:'پاسخ نامعتبر' }; }

  if(res.status === 401){
    currentUser = null;
    showBoot('نشست شما منقضی شده است. در حال انتقال به صفحه‌ی اصلی...');
    setTimeout(()=>{ location.href = 'index.html'; }, 1200);
    throw new Error('unauthenticated');
  }
  if(res.status === 403){
    toast('شما دسترسی ادمین ندارید.', 'err');
    throw new Error(data.message || 'forbidden');
  }
  if(!res.ok) throw new Error(data.message || ('HTTP ' + res.status));
  return data;
}
const apiGet   = p      => api(p);
const apiPost  = (p,b)  => api(p,{method:'POST',body:JSON.stringify(b||{})});
const apiPut   = (p,b)  => api(p,{method:'PUT',body:JSON.stringify(b||{})});
const apiPatch = (p,b)  => api(p,{method:'PATCH',body:JSON.stringify(b||{})});
const apiDel   = p      => api(p,{method:'DELETE'});

/* ---------- state ---------- */
const state = {
  page:'dashboard',
  categories:[],
  refresh:null,
  theme: getStore('bz.adm.theme','light')
};
document.documentElement.dataset.admTheme = state.theme;

/* ---------- toast ---------- */
function toast(msg,type='info',dur=3200){
  const box = $('#toasts');
  const el = document.createElement('div');
  el.className = 'adm-toast ' + (type==='ok'?'ok':type==='err'?'err':type==='warn'?'warn':'');
  const iconName = type==='ok'?'check':type==='err'?'x':type==='warn'?'x':'check';
  el.innerHTML = `
    <div class="adm-toast-ic">${ic(iconName,18)}</div>
    <div class="adm-toast-msg">${esc(msg)}</div>
    <button class="adm-toast-x" type="button" aria-label="بستن">${ic('x',16)}</button>
  `;
  const remove = ()=>{ el.classList.add('out'); setTimeout(()=>el.remove(),200); };
  el.querySelector('.adm-toast-x').addEventListener('click',remove);
  box.appendChild(el);
  setTimeout(remove,dur);
}

/* ---------- modal ---------- */
let modalLastFocus = null;
function openModal(html){
  const m = $('#modal');
  modalLastFocus = document.activeElement;
  $('#modalBox').innerHTML = html;
  m.hidden = false;
  document.documentElement.style.overflow = 'hidden';
  const focusEl = $('#modalBox').querySelector('[data-autofocus]');
  if(focusEl) setTimeout(()=>focusEl.focus(),40);
}
function closeModal(){
  /* __CLEAR_ACTIVE_F_ON_CLOSE__ */
  try{ window.__activeProductF = null; window.__activeProductRepaint = null; }catch(e){}
  $('#modal').hidden = true;
  $('#modalBox').innerHTML = '';
  document.documentElement.style.overflow = '';
  if(modalLastFocus && modalLastFocus.focus) modalLastFocus.focus();
}
$('#modal').addEventListener('click', e=>{
  if(e.target.dataset.close !== undefined) closeModal();
});

/* ---------- confirm ---------- */
function confirmDialog({title, message, confirmText='حذف', danger=true}){
  return new Promise(resolve=>{
    const c = $('#confirmModal');
    $('#confirmBox').innerHTML = `
      <div class="adm-confirm-in">
        <div class="adm-confirm-ic">${ic('trash',28)}</div>
        <h3>${esc(title)}</h3>
        <p>${esc(message)}</p>
      </div>
      <div class="adm-confirm-foot">
        <button class="adm-btn outline" data-confirm-cancel>انصراف</button>
        <button class="adm-btn ${danger?'danger':'primary'}" data-confirm-ok data-autofocus>${esc(confirmText)}</button>
      </div>
    `;
    c.hidden = false;
    const close = ok=>{ c.hidden = true; resolve(ok); };
    $('#confirmBox').querySelector('[data-confirm-ok]').onclick = ()=>close(true);
    $('#confirmBox').querySelector('[data-confirm-cancel]').onclick = ()=>close(false);
    c.querySelector('[data-confirm-close]').onclick = ()=>close(false);
  });
}

/* ---------- nav ---------- */
const PAGES = [
  { id:'dashboard',  label:'داشبورد',   icon:'dashboard' },
  { id:'products',   label:'محصولات',   icon:'box' },
  { id:'categories', label:'دسته‌بندی‌ها', icon:'grid' },
  { id:'orders',     label:'سفارش‌ها',  icon:'cart' },
  { id:'users',      label:'کاربران',   icon:'users' },
  { id:'reviews',    label:'نظرات',     icon:'star' },
  { id:'cms_pages',   label:'صفحات سایت', icon:'file' },
  { id:'cms_banners', label:'بنرها',      icon:'image' },
  { id:'cms_sliders', label:'اسلایدر',    icon:'layers' },
  { id:'account',    label:'حساب من',   icon:'user' }
];
function renderNav(){
  const nav = $('#nav');
  nav.innerHTML = PAGES.map(p=>`
    <a class="adm-nav-it ${state.page===p.id?'active':''}" data-page="${p.id}" tabindex="0">
      <span class="adm-nav-ic" data-ic="${p.icon}"></span><span>${p.label}</span>
    </a>
  `).join('');
  hydrateIcons(nav);
  $$('.adm-nav-it',nav).forEach(el=>{
    el.onclick = ()=>go(el.dataset.page);
    el.onkeydown = e=>{ if(e.key==='Enter'||e.key===' '){ e.preventDefault(); go(el.dataset.page); } };
  });
}

function go(page){
  state.page = page;
  $$('.adm-nav-it').forEach(el=>el.classList.toggle('active', el.dataset.page===page));
  closeSidebar();
  const P = PAGES.find(p=>p.id===page);
  $('#pageTitle').textContent = P ? P.label : '';
  $('#pageSub').textContent = '';
  const c = $('#content');
  c.innerHTML = '';
  if(page==='dashboard')  renderDashboard(c);
  else if(page==='products')   renderProducts(c);
  else if(page==='categories') renderCategories(c);
  else if(page==='orders')     renderOrders(c);
  else if(page==='users')      renderUsers(c);
  else if(page==='reviews')    renderReviews(c);
  else if(page==='cms_pages')   renderCmsPages(c);
  else if(page==='cms_banners') renderCmsBanners(c);
  else if(page==='cms_sliders') renderCmsSliders(c);
  else if(page==='account')    renderAccount(c);
}

/* ---------- sidebar (mobile) ---------- */
function openSidebar(){ $('#sidebar').classList.add('open'); $('#sideScrim').hidden = false; }
function closeSidebar(){ $('#sidebar').classList.remove('open'); $('#sideScrim').hidden = true; }
$('#menuBtn').onclick = openSidebar;
$('#sideScrim').onclick = closeSidebar;

/* ---------- theme ---------- */
$('#themeBtn').onclick = ()=>{
  state.theme = state.theme==='dark' ? 'light' : 'dark';
  document.documentElement.dataset.admTheme = state.theme;
  setStore('bz.adm.theme', state.theme);
};

/* ---------- refresh ---------- */
$('#refreshBtn').onclick = ()=>{ if(state.refresh) state.refresh(); };

/* ---------- user menu ---------- */
const chip = $('#userChip');
chip.addEventListener('click', e=>{
  if(e.target.closest('[data-user-menu]')) return;
  const m = $('#userMenu');
  m.hidden = !m.hidden;
  chip.classList.toggle('open', !m.hidden);
});
chip.addEventListener('keydown', e=>{
  if(e.key==='Enter' || e.key===' '){ e.preventDefault(); chip.click(); }
});
document.addEventListener('click', e=>{
  if(!e.target.closest('#userChip')){ $('#userMenu').hidden = true; chip.classList.remove('open'); }
});
$('#userMenu').addEventListener('click', async e=>{
  const btn = e.target.closest('[data-user-menu]');
  if(!btn) return;
  const a = btn.dataset.userMenu;
  $('#userMenu').hidden = true; chip.classList.remove('open');
  if(a==='account') go('account');
  else if(a==='site') window.open('index.html','_blank');
  else if(a==='logout'){
    const ok = await confirmDialog({title:'خروج از حساب', message:'مطمئنید می‌خواهید خارج شوید؟', confirmText:'خروج'});
    if(!ok) return;
    try{ await apiPost('/auth/logout'); }catch(_){}
    location.href = 'index.html';
  }
});

/* ---------- boot ---------- */
function showBoot(msg){
  const b = $('#bootLoader');
  b.hidden = false;
  $('#app').hidden = true;
  if(msg) $('#bootMsg').textContent = msg;
}

/* ================================================================
   PAGE: Dashboard
   ================================================================ */
async function renderDashboard(root){
  root.innerHTML = `
    <div class="adm-dash-loading">
      <div class="adm-sk" style="height:120px;border-radius:18px;margin-bottom:14px"></div>
      <div class="adm-sk" style="height:80px;border-radius:16px;margin-bottom:14px"></div>
      <div class="adm-sk" style="height:260px;border-radius:18px"></div>
    </div>
  `;

  let d = null;
  try{
    d = await apiGet('/orders/admin/full-dashboard');
  }catch(e){
    root.innerHTML = '<div class="adm-empty" style="padding:60px 20px">'
      + '<div class="adm-empty-ic">'
      + '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>'
      + '</div>'
      + '<h3>خطا در بارگذاری داشبورد</h3>'
      + '<p>' + esc(e.message || 'نامشخص') + '</p>'
      + '<button class="adm-btn primary" onclick="location.reload()">تلاش دوباره</button>'
      + '</div>';
    return;
  }

  const num = function(n){ return fa(Math.round(Number(n)||0)); };
  const money = function(n){ return fa(Math.round(Number(n)||0)) + ' <small>تومان</small>'; };

  const STATUS_LABELS = {
    pending:'در انتظار پرداخت', paid:'پرداخت‌شده', processing:'در حال پردازش',
    shipped:'ارسال‌شده', delivered:'تحویل‌شده',
    cancelled:'لغو‌شده', refunded:'مرجوعی'
  };
  const STATUS_CLS = {
    pending:'warn', paid:'info', processing:'info', shipped:'brand',
    delivered:'ok', cancelled:'danger', refunded:'danger'
  };

  const now = new Date();
  const dateStr = now.toLocaleDateString('fa-IR', { weekday:'long', year:'numeric', month:'long', day:'numeric' });
  const hour = now.getHours();
  const greet = hour < 12 ? 'صبح بخیر' : hour < 17 ? 'وقت بخیر' : 'شب بخیر';

  /* ---------- Hero ---------- */
  const greetHTML = `
    <div class="adm-dash-hero">
      <div class="adm-dash-hero-bg"></div>
      <div class="adm-dash-hero-body">
        <div class="adm-dash-hero-txt">
          <span class="adm-dash-eyebrow">داشبورد مدیریت</span>
          <h2>${greet}، ${esc((currentUser && currentUser.name) ? currentUser.name : 'مدیر')} 👋</h2>
          <p class="adm-dash-hero-date">${esc(dateStr)}</p>
        </div>
        <div class="adm-dash-hero-quick">
          <a class="adm-quick-action" href="index.html" target="_blank" rel="noopener">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h6v6M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/></svg>
            مشاهده سایت
          </a>
          <button class="adm-quick-action" data-dash-tab="products" type="button">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>
            افزودن محصول
          </button>
        </div>
      </div>
    </div>
  `;

  /* ---------- Alerts ---------- */
  let alertsHTML = '';
  if(d.alerts && d.alerts.length){
    const alertsInner = d.alerts.map(function(a){
      return '<div class="adm-dash-alert is-' + esc(a.type) + '">'
        + '<span class="adm-dash-alert-ic">' + ic(a.icon||'x',16) + '</span>'
        + '<span>' + esc(a.text) + '</span>'
        + '</div>';
    }).join('');
    alertsHTML = '<div class="adm-dash-alerts">' + alertsInner + '</div>';
  }

  /* ---------- KPI 1: Sales ---------- */
  const salesKPI = `
    <div class="adm-dash-section">
      <div class="adm-dash-sec-head">
        <h3>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M22 7 13.5 15.5l-5-5L2 17"/><path d="M16 7h6v6"/></svg>
          فروش
        </h3>
      </div>
      <div class="adm-kpi-grid is-4">
        <div class="adm-kpi is-sales">
          <div class="adm-kpi-top">
            <span class="adm-kpi-lbl">امروز</span>
            <span class="adm-kpi-chip">${num(d.today.orders)} سفارش</span>
          </div>
          <div class="adm-kpi-val">${money(d.today.revenue)}</div>
        </div>
        <div class="adm-kpi is-sales">
          <div class="adm-kpi-top">
            <span class="adm-kpi-lbl">۷ روز اخیر</span>
            <span class="adm-kpi-chip">${num(d.week.orders)} سفارش</span>
          </div>
          <div class="adm-kpi-val">${money(d.week.revenue)}</div>
        </div>
        <div class="adm-kpi is-sales">
          <div class="adm-kpi-top">
            <span class="adm-kpi-lbl">۳۰ روز اخیر</span>
            <span class="adm-kpi-chip">${num(d.month.orders)} سفارش</span>
          </div>
          <div class="adm-kpi-val">${money(d.month.revenue)}</div>
        </div>
        <div class="adm-kpi is-sales">
          <div class="adm-kpi-top">
            <span class="adm-kpi-lbl">امسال</span>
            <span class="adm-kpi-chip">${num(d.year.orders)} سفارش</span>
          </div>
          <div class="adm-kpi-val">${money(d.year.revenue)}</div>
        </div>
      </div>
    </div>
  `;

  /* ---------- KPI 2: Order statuses ---------- */
  const orderStatuses = ['pending','paid','processing','shipped','delivered','cancelled'];
  const ordersKPI = `
    <div class="adm-dash-section">
      <div class="adm-dash-sec-head">
        <h3>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 8v8a2 2 0 0 1-1 1.73l-7 4a2 2 0 0 1-2 0l-7-4A2 2 0 0 1 3 16V8a2 2 0 0 1 1-1.73l7-4a2 2 0 0 1 2 0l7 4A2 2 0 0 1 21 8z"/></svg>
          وضعیت سفارش‌ها
        </h3>
        <button class="adm-btn ghost sm" data-dash-tab="orders" type="button">مشاهده همه</button>
      </div>
      <div class="adm-kpi-grid is-6">
        ${orderStatuses.map(function(st){
          return '<div class="adm-kpi is-status" data-dash-tab="orders" role="button" tabindex="0">'
            + '<span class="adm-status-dot is-' + (STATUS_CLS[st]||'') + '"></span>'
            + '<div class="adm-kpi-lbl">' + STATUS_LABELS[st] + '</div>'
            + '<div class="adm-kpi-val-lg">' + num(d.statusCounts[st]||0) + '</div>'
            + '</div>';
        }).join('')}
      </div>
    </div>
  `;

  /* ---------- KPI 3: Finance + inventory ---------- */
  const finKPI = `
    <div class="adm-dash-section">
      <div class="adm-dash-sec-head">
        <h3>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18"/></svg>
          موجودی و مالی
        </h3>
      </div>
      <div class="adm-kpi-grid is-3">
        <div class="adm-kpi is-wallet">
          <div class="adm-kpi-head">
            <span class="adm-kpi-icon is-ok">${ic('wallet',18)}</span>
            <span class="adm-kpi-lbl">درآمد کل</span>
          </div>
          <div class="adm-kpi-val">${money(d.revenue)}</div>
          <div class="adm-kpi-sub">از سفارش‌های موفق</div>
        </div>
        <div class="adm-kpi is-wallet">
          <div class="adm-kpi-head">
            <span class="adm-kpi-icon is-warn">${ic('cart',18)}</span>
            <span class="adm-kpi-lbl">طلب از مشتریان</span>
          </div>
          <div class="adm-kpi-val">${money(d.pendingAmount)}</div>
          <div class="adm-kpi-sub">سفارش‌های در انتظار پرداخت</div>
        </div>
        <div class="adm-kpi is-wallet">
          <div class="adm-kpi-head">
            <span class="adm-kpi-icon is-info">${ic('users',18)}</span>
            <span class="adm-kpi-lbl">تعداد مشتریان</span>
          </div>
          <div class="adm-kpi-val-lg">${num(d.users)}</div>
          <div class="adm-kpi-sub">کاربران ثبت‌نام‌شده</div>
        </div>
      </div>

      <div class="adm-kpi-grid is-3" style="margin-top:14px">
        <div class="adm-kpi is-inv">
          <div class="adm-kpi-head">
            <span class="adm-kpi-icon is-brand">${ic('box',18)}</span>
            <span class="adm-kpi-lbl">کل محصولات</span>
          </div>
          <div class="adm-kpi-val-lg">${num(d.products.total)}</div>
        </div>
        <div class="adm-kpi is-inv">
          <div class="adm-kpi-head">
            <span class="adm-kpi-icon is-warn">${ic('trend',18)}</span>
            <span class="adm-kpi-lbl">موجودی کم</span>
          </div>
          <div class="adm-kpi-val-lg">${num(d.products.lowStock)}</div>
          <div class="adm-kpi-sub">کمتر از ۵ عدد</div>
        </div>
        <div class="adm-kpi is-inv">
          <div class="adm-kpi-head">
            <span class="adm-kpi-icon is-danger">${ic('x',18)}</span>
            <span class="adm-kpi-lbl">ناموجود</span>
          </div>
          <div class="adm-kpi-val-lg">${num(d.products.outOfStock)}</div>
          <div class="adm-kpi-sub">نیاز به تأمین</div>
        </div>
      </div>
    </div>
  `;

  /* ---------- Daily line chart ---------- */
  const dailyArr = d.chartDaily || [];
  let dailyMax = 1;
  dailyArr.forEach(function(it){ if(it.revenue > dailyMax) dailyMax = it.revenue; });

  const CW = 640, CH = 200, CP = 34;
  const steps = Math.max(1, dailyArr.length - 1);
  const stepX = (CW - CP*2) / steps;

  const dailyPoints = dailyArr.map(function(item, i){
    const px = CP + i * stepX;
    const py = CH - CP - (item.revenue / dailyMax) * (CH - CP*2 - 16);
    return { px: px, py: py, revenue: item.revenue, date: item.date };
  });

  let linePath = '';
  dailyPoints.forEach(function(p, i){
    linePath += (i===0 ? 'M' : 'L') + p.px + ' ' + p.py + ' ';
  });
  let areaPath = linePath;
  if(dailyPoints.length){
    areaPath += 'L ' + dailyPoints[dailyPoints.length-1].px + ' ' + (CH - CP) + ' ';
    areaPath += 'L ' + dailyPoints[0].px + ' ' + (CH - CP) + ' Z';
  }

  const shortDay = function(iso){
    const dt = new Date(iso);
    return ['ی','د','س','چ','پ','ج','ش'][dt.getDay()] || '?';
  };

  let dailyCircles = '';
  dailyPoints.forEach(function(p){
    dailyCircles += '<g>'
      + '<circle cx="' + p.px + '" cy="' + p.py + '" r="4.5" fill="var(--adm-surface)" stroke="var(--adm-brand)" stroke-width="2.5"/>'
      + '<text x="' + p.px + '" y="' + (CH - 12) + '" text-anchor="middle" font-size="11" fill="var(--adm-muted)" font-family="Vazirmatn" direction="rtl">' + esc(shortDay(p.date)) + '</text>'
      + '</g>';
  });

  let dailyTotal = 0;
  dailyArr.forEach(function(it){ dailyTotal += it.revenue; });

  const salesChartHTML = '<div class="adm-chart-card">'
    + '<div class="adm-chart-head">'
    + '<h3><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="M7 14l4-4 4 4 6-6"/></svg> نمودار فروش ۷ روز اخیر</h3>'
    + '<span class="adm-chart-meta">مجموع: ' + money(dailyTotal) + '</span>'
    + '</div>'
    + '<div class="adm-chart-body">'
    + '<svg viewBox="0 0 640 200" class="adm-line-chart" preserveAspectRatio="none">'
    + '<defs><linearGradient id="lineGrad" x1="0" y1="0" x2="0" y2="1">'
    + '<stop offset="0" stop-color="var(--adm-brand)" stop-opacity="0.28"/>'
    + '<stop offset="1" stop-color="var(--adm-brand)" stop-opacity="0"/>'
    + '</linearGradient></defs>'
    + '<path d="' + areaPath + '" fill="url(#lineGrad)"/>'
    + '<path d="' + linePath + '" fill="none" stroke="var(--adm-brand)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>'
    + dailyCircles
    + '</svg></div></div>';

  /* ---------- Monthly bar chart ---------- */
  const monthlyArr = d.chartMonthly || [];
  let monthMax = 1;
  monthlyArr.forEach(function(it){ if(it.revenue > monthMax) monthMax = it.revenue; });

  const barW = 60, gap = 32, padX = 40, padY = 30;
  const monthNames = ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];

  let monthlyBarsHTML = '';
  monthlyArr.forEach(function(item, i){
    const bh = (item.revenue / monthMax) * (CH - padY*2);
    const bx = padX + i * (barW + gap);
    const by = CH - padY - bh;
    const mn = parseInt(item.month.split('-')[1], 10) - 1;
    const label = (monthNames[mn] || '?').slice(0, 4);
    monthlyBarsHTML += '<g>'
      + '<rect x="' + bx + '" y="' + by + '" width="' + barW + '" height="' + Math.max(2, bh) + '" rx="8" fill="url(#barGrad)"/>'
      + '<text x="' + (bx + barW/2) + '" y="' + (CH - 10) + '" text-anchor="middle" font-size="11" fill="var(--adm-muted)" font-family="Vazirmatn" direction="rtl">' + esc(label) + '</text>'
      + '</g>';
  });

  let monthTotal = 0;
  monthlyArr.forEach(function(it){ monthTotal += it.revenue; });

  const monthlyChartHTML = '<div class="adm-chart-card">'
    + '<div class="adm-chart-head">'
    + '<h3><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="18" rx="1"/><rect x="14" y="8" width="7" height="13" rx="1"/></svg> نمودار فروش ۶ ماه اخیر</h3>'
    + '<span class="adm-chart-meta">مجموع: ' + money(monthTotal) + '</span>'
    + '</div>'
    + '<div class="adm-chart-body">'
    + '<svg viewBox="0 0 640 200" class="adm-bar-chart" preserveAspectRatio="none">'
    + '<defs><linearGradient id="barGrad" x1="0" y1="0" x2="0" y2="1">'
    + '<stop offset="0" stop-color="var(--adm-brand)"/>'
    + '<stop offset="1" stop-color="var(--adm-brand)" stop-opacity="0.55"/>'
    + '</linearGradient></defs>'
    + monthlyBarsHTML
    + '</svg></div></div>';

  /* ---------- Best sellers ---------- */
  let bestInner = '';
  if(d.bestSellers && d.bestSellers.length){
    bestInner = d.bestSellers.map(function(p, i){
      const rankCls = i < 3 ? ' is-top' : '';
      return '<div class="adm-best-item">'
        + '<span class="adm-best-rank' + rankCls + '">' + fa(i+1) + '</span>'
        + '<div class="adm-best-thumb">' + ic(p.art||'box',20) + '</div>'
        + '<div class="adm-best-info">'
        + '<b>' + esc(p.name) + '</b>'
        + '<span>' + esc(p.brand||'') + '</span>'
        + '</div>'
        + '<div class="adm-best-meta">'
        + '<div class="adm-best-sales">' + num(p.sales) + ' فروش</div>'
        + '<div class="adm-best-rev">' + money(p.revenue) + '</div>'
        + '</div>'
        + '</div>';
    }).join('');
  }else{
    bestInner = '<div class="adm-empty" style="padding:40px 16px"><h3>محصولی موجود نیست</h3></div>';
  }

  const bestHTML = '<div class="adm-dash-panel">'
    + '<div class="adm-dash-panel-head">'
    + '<h3><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l2.7 5.5 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.8 1-6.1L3.2 9.4l6.1-.9z"/></svg> پرفروش‌ترین محصولات</h3>'
    + '<button class="adm-btn ghost sm" data-dash-tab="products" type="button">مشاهده محصولات</button>'
    + '</div>'
    + '<div class="adm-best-list">' + bestInner + '</div>'
    + '</div>';

  /* ---------- Latest orders ---------- */
  let latestInner = '';
  if(d.latestOrders && d.latestOrders.length){
    latestInner = d.latestOrders.map(function(o){
      const stLabel = STATUS_LABELS[o.status] || o.status;
      const stCls = STATUS_CLS[o.status] || '';
      return '<div class="adm-latest-item" data-dash-order="' + o.id + '">'
        + '<div class="adm-latest-ic">'
        + '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 8v8a2 2 0 0 1-1 1.73l-7 4a2 2 0 0 1-2 0l-7-4A2 2 0 0 1 3 16V8a2 2 0 0 1 1-1.73l7-4a2 2 0 0 1 2 0l7 4A2 2 0 0 1 21 8z"/></svg>'
        + '</div>'
        + '<div class="adm-latest-info">'
        + '<b dir="ltr">' + esc(o.trackingCode) + '</b>'
        + '<span>' + esc(o.customer||'—') + '</span>'
        + '</div>'
        + '<div class="adm-latest-meta">'
        + '<div class="adm-latest-amt">' + money(o.total) + '</div>'
        + '<span class="adm-bdg ' + stCls + '">' + esc(stLabel) + '</span>'
        + '</div>'
        + '</div>';
    }).join('');
  }else{
    latestInner = '<div class="adm-empty" style="padding:40px 16px"><h3>هنوز سفارشی ثبت نشده</h3></div>';
  }

  const latestHTML = '<div class="adm-dash-panel">'
    + '<div class="adm-dash-panel-head">'
    + '<h3><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg> آخرین سفارش‌ها</h3>'
    + '<button class="adm-btn ghost sm" data-dash-tab="orders" type="button">همه سفارش‌ها</button>'
    + '</div>'
    + '<div class="adm-latest-list">' + latestInner + '</div>'
    + '</div>';

  /* ---------- Final render ---------- */
  root.innerHTML = greetHTML
    + alertsHTML
    + salesKPI
    + ordersKPI
    + finKPI
    + '<div class="adm-chart-grid">' + salesChartHTML + monthlyChartHTML + '</div>'
    + '<div class="adm-dash-cols">' + bestHTML + latestHTML + '</div>';

  /* ---------- Click handlers ---------- */
  root.querySelectorAll('[data-dash-tab]').forEach(function(b){
    b.addEventListener('click', function(){ go(b.dataset.dashTab); });
  });
  root.querySelectorAll('[data-dash-order]').forEach(function(b){
    b.addEventListener('click', function(){ go('orders'); });
  });
}

/* ================================================================
   PAGE: Products
   ================================================================ */
async function renderProducts(root){
  root.innerHTML = `
    <div class="adm-sec-head">
      <h2>محصولات</h2>
      <span class="adm-sec-sub" id="prodCount"></span>
      <div class="adm-sec-actions">
        <button class="adm-btn outline sm" id="prodRefresh" type="button">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-3-6.7M21 4v6h-6"/></svg>
          بروزرسانی
        </button>
        <button class="adm-btn primary" id="btnNewProd" type="button">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>
          افزودن محصول
        </button>
      </div>
    </div>

    <div class="adm-card">
      <div class="adm-toolbar adm-prod-toolbar">
        <div class="adm-search">
          <span class="adm-search-ic">${ic('search',18)}</span>
          <input id="prodQ" placeholder="جستجوی نام، SKU، برند..." autocomplete="off">
        </div>
        <select class="adm-select" id="prodCatFilter" style="max-width:180px">
          <option value="">همه دسته‌ها</option>
        </select>
        <select class="adm-select" id="prodStockFilter" style="max-width:180px">
          <option value="">همه موجودی‌ها</option>
          <option value="instock">موجود</option>
          <option value="low">موجودی کم</option>
          <option value="out">ناموجود</option>
        </select>
        <select class="adm-select" id="prodStatusFilter" style="max-width:170px">
          <option value="">همه وضعیت‌ها</option>
          <option value="1">فعال</option>
          <option value="0">غیرفعال</option>
        </select>
      </div>

      <div class="adm-tbl-wrap">
        <table class="adm-tbl adm-prod-tbl">
          <thead>
            <tr>
              <th>محصول</th>
              <th>SKU</th>
              <th>دسته</th>
              <th>قیمت فروش</th>
              <th>سود</th>
              <th>موجودی</th>
              <th>وضعیت</th>
              <th class="col-actions">عملیات</th>
            </tr>
          </thead>
          <tbody id="prodBody"></tbody>
        </table>
      </div>
    </div>
  `;

  const body = root.querySelector('#prodBody');
  const cntEl = root.querySelector('#prodCount');
  let all = [];

  function paint(){
    const q = root.querySelector('#prodQ').value.trim().toLowerCase();
    const catF = root.querySelector('#prodCatFilter').value;
    const stF = root.querySelector('#prodStockFilter').value;
    const pubF = root.querySelector('#prodStatusFilter').value;

    const list = all.filter(function(p){
      if(q){
        const h = (p.name + ' ' + (p.sku||'') + ' ' + (p.brand||'')).toLowerCase();
        if(!h.includes(q)) return false;
      }
      if(catF && (p.category && (p.category.slug || String(p.category.id))) !== catF) return false;
      if(pubF !== '' && String(p.isActive ? 1 : 0) !== pubF) return false;
      if(stF === 'instock' && p.stock <= 0) return false;
      if(stF === 'low' && !(p.stock > 0 && p.stock <= (p.minStock||3))) return false;
      if(stF === 'out' && p.stock > 0) return false;
      return true;
    });

    cntEl.textContent = fa(list.length) + ' محصول';

    if(!list.length){
      body.innerHTML = '<tr><td colspan="8"><div class="adm-empty" style="padding:52px 16px">'
        + '<div class="adm-empty-ic">'
        + '<svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M21 8v8a2 2 0 0 1-1 1.73l-7 4a2 2 0 0 1-2 0l-7-4A2 2 0 0 1 3 16V8a2 2 0 0 1 1-1.73l7-4a2 2 0 0 1 2 0l7 4A2 2 0 0 1 21 8z"/></svg>'
        + '</div><h3>محصولی پیدا نشد</h3><p>فیلترها را تغییر دهید یا محصول جدیدی اضافه کنید.</p>'
        + '</div></td></tr>';
      return;
    }

    body.innerHTML = list.map(function(p){
      const mainColor = (p.colors && p.colors[0]) ? p.colors[0].hex : '#94a3b8';
      const finalPrice = p.finalPrice || Math.round(p.price*(1-(p.off||0)/100)/1000)*1000;
      const profit = (p.purchasePrice > 0) ? (p.price - p.purchasePrice) : null;
      const profitPct = profit !== null && p.purchasePrice > 0 ? Math.round((profit / p.purchasePrice) * 100) : null;

      let stockBadge;
      if(p.stock <= 0) stockBadge = '<span class="adm-bdg danger">ناموجود</span>';
      else if(p.stock <= (p.minStock||3)) stockBadge = '<span class="adm-bdg warn">' + fa(p.stock) + ' عدد (کم)</span>';
      else stockBadge = '<span class="adm-bdg ok">' + fa(p.stock) + ' عدد</span>';

      const pubBadge = p.isActive
        ? '<span class="adm-bdg ok">منتشرشده</span>'
        : '<span class="adm-bdg">پیش‌نویس</span>';

      const catName = p.category ? p.category.name : '—';
      const catColor = p.category ? (p.category.color || '#94a3b8') : '#94a3b8';

      const imgCount = (p.images && p.images.length) || 0;

      return '<tr data-prod-row="' + p.id + '">'
        + '<td><div class="adm-prod-row">'
        + '<div class="adm-prod-thumb" style="--tint:' + mainColor + ';position:relative;overflow:hidden">'
          + (window.__resolveCardImg(p) ? '<img src="' + window.__resolveCardImg(p) + '" alt="" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover" onerror="this.style.display=\'none\'">' : '')
          + '<span style="position:relative;z-index:0;display:grid;place-items:center;width:100%;height:100%">' + ic(p.art || 'box', 22) + '</span>'
        + '</div>'
        + '<div class="adm-prod-info">'
        + '<b>' + esc(p.name) + '</b>'
        + '<span>' + esc(p.brand || '') + (imgCount ? ' · ' + fa(imgCount) + ' تصویر' : '') + '</span>'
        + (imgCount ? '<div class="adm-prod-thumbs-row">' + (p.images || []).slice(0,4).map(function(u){ var abs = (window.__ASSET__ ? window.__ASSET__(u) : u); return '<span class="adm-mini-thumb"><img src="' + abs + '" alt=""></span>'; }).join('') + ((p.images && p.images.length > 4) ? '<span class="adm-more">+' + fa(p.images.length - 4) + '</span>' : '') + '</div>' : '')
        + '</div>'
        + '</div></td>'
        + '<td><code class="adm-sku">' + esc(p.sku || '—') + '</code></td>'
        + '<td><span class="adm-bdg" style="--c:' + catColor + '">'
        + '<i style="background:' + catColor + '"></i>' + esc(catName) + '</span></td>'
        + '<td><div class="adm-price-cell">'
        + (p.off > 0 ? '<s>' + fa(p.price) + '</s>' : '')
        + '<b>' + fa(finalPrice) + '</b>'
        + (p.off > 0 ? '<span class="adm-off-pct">-' + fa(p.off) + '٪</span>' : '')
        + '</div></td>'
        + '<td>'
        + (profit !== null
            ? '<div class="adm-profit"><b style="color:' + (profit > 0 ? 'var(--adm-ok)' : 'var(--adm-danger)') + '">' + fa(profit) + '</b>'
              + '<span>' + (profitPct !== null ? fa(profitPct) + '٪' : '') + '</span></div>'
            : '<span class="adm-hint">—</span>')
        + '</td>'
        + '<td>' + stockBadge + '</td>'
        + '<td>' + pubBadge + '</td>'
        + '<td class="col-actions"><div class="adm-tbl-actions">'
        + '<button class="adm-iconbtn-sm" data-view="' + p.id + '" title="مشاهده">'
        + '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z"/><circle cx="12" cy="12" r="3"/></svg>'
        + '</button>'
        + '<button class="adm-iconbtn-sm" data-edit="' + p.id + '" title="ویرایش">'
        + '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.1 2.1 0 1 1 3 3L12 15l-4 1 1-4z"/></svg>'
        + '</button>'
        + '<button class="adm-iconbtn-sm" data-dup="' + p.id + '" title="کپی">'
        + '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>'
        + '</button>'
        + '<button class="adm-iconbtn-sm" data-toggle="' + p.id + '" title="' + (p.isActive ? 'غیرفعال' : 'فعال') + '">'
        + (p.isActive
            ? '<svg width="16" height="16" viewBox="0 0 24 24"><rect x="2" y="6" width="20" height="12" rx="6" fill="currentColor"/><circle cx="17" cy="12" r="4" fill="#fff"/></svg>'
            : '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="6" width="20" height="12" rx="6"/><circle cx="7" cy="12" r="3" fill="currentColor"/></svg>')
        + '</button>'
        + '<button class="adm-iconbtn-sm danger" data-del="' + p.id + '" title="حذف">'
        + '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>'
        + '</button>'
        + '</div></td>'
        + '</tr>';
    }).join('');

    body.querySelectorAll('[data-edit]').forEach(function(b){ b.onclick = function(){ openProductForm(+b.dataset.edit); }; });
    body.querySelectorAll('[data-view]').forEach(function(b){ b.onclick = function(){ openProductView(+b.dataset.view); }; });
    body.querySelectorAll('[data-dup]').forEach(function(b){ b.onclick = function(){ duplicateProd(+b.dataset.dup); }; });
    body.querySelectorAll('[data-toggle]').forEach(function(b){ b.onclick = function(){ toggleProd(+b.dataset.toggle); }; });
    body.querySelectorAll('[data-del]').forEach(function(b){ b.onclick = function(){ deleteProd(+b.dataset.del); }; });
  }

  async function load(){
    body.innerHTML = '<tr><td colspan="8"><div style="padding:32px;text-align:center;color:var(--adm-muted)">در حال بارگذاری...</div></td></tr>';
    try{
      const [prodRes, catRes] = await Promise.all([
        apiGet('/products?limit=200'),
        apiGet('/categories')
      ]);
      all = prodRes.items || [];
      const cats = catRes.categories || [];
      state.categories = cats;
      const catSel = root.querySelector('#prodCatFilter');
      catSel.innerHTML = '<option value="">همه دسته‌ها</option>'
        + cats.map(function(c){ return '<option value="' + esc(c.slug || c.id) + '">' + esc(c.name) + '</option>'; }).join('');
      paint();
    }catch(e){
      body.innerHTML = '<tr><td colspan="8" style="padding:32px;text-align:center;color:var(--adm-danger)">' + esc(e.message) + '</td></tr>';
    }
  }

  let timer;
  ['prodQ'].forEach(function(id){
    root.querySelector('#' + id).addEventListener('input', function(){
      clearTimeout(timer); timer = setTimeout(paint, 250);
    });
  });
  ['prodCatFilter','prodStockFilter','prodStatusFilter'].forEach(function(id){
    root.querySelector('#' + id).addEventListener('change', paint);
  });
  root.querySelector('#prodRefresh').addEventListener('click', load);
  root.querySelector('#btnNewProd').addEventListener('click', function(){ openProductForm(null); });

  state.refresh = load;
  load();
}


/* ================================================================
   Product View Modal
   ================================================================ */
async function openProductView(id){
  let p = null;
  try{
    const r = await apiGet('/products/' + id);
    p = r.product;
    try{ window.__curPmAdminProduct = p; }catch(e){}
  }catch(e){ toast('خطا: ' + e.message, 'err'); return; }

  const money = n => fa(Math.round(Number(n)||0)) + ' تومان';
  const finalPrice = p.finalPrice || Math.round(p.price*(1-(p.off||0)/100)/1000)*1000;
  const profit = (p.purchasePrice > 0) ? (p.price - p.purchasePrice) : null;
  const profitPct = profit !== null && p.purchasePrice > 0 ? Math.round((profit / p.purchasePrice) * 100) : null;
  const marginPct = p.price > 0 && p.purchasePrice > 0 ? Math.round((profit / p.price) * 100) : null;

  const artLabels = {phone:'موبایل',laptop:'لپ‌تاپ',headphones:'هدفون',watch:'ساعت',speaker:'اسپیکر',camera:'دوربین',sneaker:'کفش',backpack:'کوله',hoodie:'هودی',kettle:'کتری',lamp:'چراغ',book:'کتاب'};
  const mainColor = (p.colors && p.colors[0]) ? p.colors[0].hex : '#94a3b8';

  const images = p.images || [];
  const features = p.features || [];
  const sizes = p.sizes || [];
  const colors = p.colors || [];
  const specs = p.specs || [];

  /* stock badge */
  let stockBadge, stockText;
  if(p.stock <= 0){ stockBadge = 'danger'; stockText = 'ناموجود'; }
  else if(p.stock <= (p.minStock||3)){ stockBadge = 'warn'; stockText = 'موجودی کم'; }
  else { stockBadge = 'ok'; stockText = 'موجود'; }

  const modalEl = document.querySelector('#modal');
  const sheet = document.querySelector('#modalBox');
  if(!modalEl || !sheet){ toast('خطا: مودال پیدا نشد.', 'err'); return; }
  modalLastFocus = document.activeElement;
  sheet.className = 'adm-modal-box adm-prod-view-sheet';
  modalEl.hidden = false;
  document.documentElement.style.overflow = 'hidden';
  sheet.scrollTop = 0;

  sheet.innerHTML = `
    <div class="adm-modal-head">
      <h3>مشاهده محصول</h3>
      <button class="adm-iconbtn-sm" data-close type="button" style="margin-inline-start:auto">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>
      </button>
    </div>

    <div class="adm-pv-hero">
      <div class="adm-pv-thumb" style="--tint:${mainColor}">
        ${window.__resolveCardImg(p) ? '<img src="'+window.__resolveCardImg(p)+'" alt="" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:inherit" onerror="this.style.display=\'none\'">' : ''}
        ${ic(p.art || 'book', 60)}
        ${p.off > 0 ? '<span class="adm-pv-off">-' + fa(p.off) + '٪</span>' : ''}
      </div>
      <div class="adm-pv-hero-info">
        <div class="adm-pv-badges">
          <span class="adm-bdg ${stockBadge}">${stockText}</span>
          <span class="adm-bdg ${p.isActive ? 'ok' : ''}">${p.isActive ? 'منتشرشده' : 'پیش‌نویس'}</span>
          ${p.category ? '<span class="adm-bdg" style="--c:' + (p.category.color||'#94a3b8') + '"><i style="background:' + (p.category.color||'#94a3b8') + '"></i>' + esc(p.category.name) + '</span>' : ''}
        </div>
        <h2>${esc(p.name)}</h2>
        <div class="adm-pv-sub">
          <span>${esc(p.brand || '—')}</span>
          ${p.sku ? '<span class="adm-pv-sep"></span><code>' + esc(p.sku) + '</code>' : ''}
        </div>
        ${p.shortDescription ? '<p class="adm-pv-short">' + esc(p.shortDescription) + '</p>' : ''}
      </div>
    </div>

    <div class="adm-pv-body">

      <div class="adm-pv-section">
        <h4 class="adm-pv-title">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18"/></svg>
          قیمت و سود
        </h4>
        <div class="adm-pv-price-grid">
          <div class="adm-pv-price-box">
            <label>قیمت فروش</label>
            <div class="adm-pv-price-main">${money(p.price)}</div>
            ${p.off > 0 ? '<div class="adm-pv-price-final">نهایی: ' + money(finalPrice) + '</div>' : ''}
          </div>
          ${p.purchasePrice > 0 ? `
            <div class="adm-pv-price-box">
              <label>قیمت خرید</label>
              <div class="adm-pv-price-sub">${money(p.purchasePrice)}</div>
            </div>
          ` : ''}
          ${profit !== null ? `
            <div class="adm-pv-price-box">
              <label>سود هر فروش</label>
              <div class="adm-pv-price-profit" style="color:${profit > 0 ? 'var(--adm-ok)' : 'var(--adm-danger)'}">${money(profit)}</div>
              ${profitPct !== null ? '<div class="adm-pv-price-final">' + fa(profitPct) + '٪' + (marginPct !== null ? ' · حاشیه ' + fa(marginPct) + '٪' : '') + '</div>' : ''}
            </div>
          ` : ''}
          ${p.off > 0 ? `
            <div class="adm-pv-price-box">
              <label>تخفیف</label>
              <div class="adm-pv-price-off">${fa(p.off)}٪</div>
            </div>
          ` : ''}
        </div>
      </div>

      <div class="adm-pv-section">
        <h4 class="adm-pv-title">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 8v8a2 2 0 0 1-1 1.73l-7 4a2 2 0 0 1-2 0l-7-4A2 2 0 0 1 3 16V8a2 2 0 0 1 1-1.73l7-4a2 2 0 0 1 2 0l7 4A2 2 0 0 1 21 8z"/></svg>
          انبار
        </h4>
        <div class="adm-pv-grid">
          <div class="adm-pv-item">
            <label>موجودی فعلی</label>
            <b>${fa(p.stock)} عدد</b>
          </div>
          <div class="adm-pv-item">
            <label>حداقل موجودی</label>
            <b>${fa(p.minStock || 3)} عدد</b>
          </div>
          ${p.weight > 0 ? '<div class="adm-pv-item"><label>وزن</label><b>' + fa(p.weight) + ' گرم</b></div>' : ''}
          ${p.dimensions ? '<div class="adm-pv-item"><label>ابعاد</label><b dir="ltr">' + esc(p.dimensions) + '</b></div>' : ''}
          ${p.warranty ? '<div class="adm-pv-item"><label>گارانتی</label><b>' + esc(p.warranty) + '</b></div>' : ''}
          <div class="adm-pv-item">
            <label>فروش کل</label>
            <b>${fa(p.sales || 0)} عدد</b>
          </div>
        </div>
      </div>

      ${colors.length ? `
        <div class="adm-pv-section">
          <h4 class="adm-pv-title">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="13.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="14.5" r="2.5"/><circle cx="8.5" cy="7.5" r="2.5"/><circle cx="6.5" cy="15.5" r="2.5"/></svg>
            رنگ‌ها (${fa(colors.length)})
          </h4>
          <div class="adm-pv-colors">
            ${colors.map(function(c){
              return '<div class="adm-pv-color-chip">'
                + '<span style="background:' + esc(c.hex) + '"></span>'
                + '<b>' + esc(c.name) + '</b>'
                + '</div>';
            }).join('')}
          </div>
        </div>
      ` : ''}

      ${sizes.length ? `
        <div class="adm-pv-section">
          <h4 class="adm-pv-title">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M3 9l4-4 14 14-4 4z"/><path d="M9 5l1 3M13 9l1 3M17 13l1 3"/></svg>
            سایزها (${fa(sizes.length)})
          </h4>
          <div class="adm-pv-sizes">
            ${sizes.map(function(s){ return '<span class="adm-pv-size">' + esc(s) + '</span>'; }).join('')}
          </div>
        </div>
      ` : ''}

      ${images.length ? `
        <div class="adm-pv-section">
          <h4 class="adm-pv-title">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="M3 15l5-5 6 6 3-3 4 4"/></svg>
            تصاویر (${fa(images.length)})
          </h4>
          <div class="adm-pv-gallery">
            ${images.map(function(url){
              return '<a class="adm-pv-img" href="' + esc(window.__ASSET__(url)) + '" target="_blank" rel="noopener" style="background-image:url(\'' + esc(window.__ASSET__(url)) + '\')"></a>';
            }).join('')}
          </div>
        </div>
      ` : ''}

      ${p.videoUrl ? `
        <div class="adm-pv-section">
          <h4 class="adm-pv-title">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="14" height="12" rx="2"/><path d="M22 8l-6 4 6 4z"/></svg>
            ویدئو
          </h4>
          <div class="adm-pv-video">
            <a href="${esc(p.videoUrl)}" target="_blank" rel="noopener" dir="ltr">${esc(p.videoUrl)}</a>
          </div>
        </div>
      ` : ''}

      ${specs.length ? `
        <div class="adm-pv-section">
          <h4 class="adm-pv-title">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
            مشخصات فنی (${fa(specs.length)})
          </h4>
          <table class="adm-pv-spec-table">
            <tbody>
              ${specs.map(function(s){
                return '<tr><th>' + esc(s.key) + '</th><td>' + esc(s.value) + '</td></tr>';
              }).join('')}
            </tbody>
          </table>
        </div>
      ` : ''}

      ${features.length ? `
        <div class="adm-pv-section">
          <h4 class="adm-pv-title">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>
            ویژگی‌ها
          </h4>
          <ul class="adm-pv-features">
            ${features.map(function(f){ return '<li>' + esc(f) + '</li>'; }).join('')}
          </ul>
        </div>
      ` : ''}

      ${(p.description || p.shortDescription) ? `
        <div class="adm-pv-section">
          <h4 class="adm-pv-title">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M4 6h16M4 12h16M4 18h10"/></svg>
            توضیحات
          </h4>
          <div class="adm-pv-desc">${esc(p.description || p.shortDescription || '').replace(/\n/g, '<br>')}</div>
        </div>
      ` : ''}

      ${(p.metaTitle || p.metaDescription) ? `
        <div class="adm-pv-section">
          <h4 class="adm-pv-title">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>
            سئو
          </h4>
          ${p.metaTitle ? '<div class="adm-pv-item"><label>عنوان متا</label><b>' + esc(p.metaTitle) + '</b></div>' : ''}
          ${p.metaDescription ? '<div class="adm-pv-item" style="margin-top:8px"><label>توضیح متا</label><b>' + esc(p.metaDescription) + '</b></div>' : ''}
        </div>
      ` : ''}

      ${(p.created_at || p.updated_at) ? `
        <div class="adm-pv-section adm-pv-meta">
          ${p.created_at ? '<div><label>تاریخ ایجاد</label><b>' + new Date(p.created_at).toLocaleString('fa-IR') + '</b></div>' : ''}
          ${p.updated_at ? '<div><label>آخرین ویرایش</label><b>' + new Date(p.updated_at).toLocaleString('fa-IR') + '</b></div>' : ''}
        </div>
      ` : ''}
    </div>

    <div class="adm-modal-foot">
      <button class="adm-btn outline" data-close type="button">بستن</button>
      <button class="adm-btn primary" id="pvEditBtn" type="button">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.1 2.1 0 1 1 3 3L12 15l-4 1 1-4z"/></svg>
        ویرایش محصول
      </button>
    </div>
  `;

  sheet.querySelector('#pvEditBtn').onclick = function(){
    closeModal();
    setTimeout(function(){ openProductForm(id); }, 200);
  };
}

async function duplicateProd(id){
  const ok = await confirmDialog({
    title:'کپی محصول',
    message:'یک نسخه‌ی کپی از این محصول ساخته می‌شود. ادامه؟',
    confirmText:'کپی کن',
    danger:false
  });
  if(!ok) return;
  try{
    await apiPost('/products/' + id + '/duplicate');
    toast('محصول کپی شد.', 'ok');
    if(state.refresh) state.refresh();
  }catch(e){ toast('خطا: ' + e.message, 'err'); }
}

async function toggleProd(id){
  try{
    await apiPatch('/products/' + id + '/toggle');
    toast('وضعیت تغییر کرد.', 'ok');
    if(state.refresh) state.refresh();
  }catch(e){ toast('خطا: ' + e.message, 'err'); }
}

async function deleteProd(id){
  const ok = await confirmDialog({
    title:'حذف محصول',
    message:'این محصول برای همیشه حذف می‌شود. مطمئنید؟',
    confirmText:'حذف کن'
  });
  if(!ok) return;
  try{
    await apiDel('/products/' + id);
    toast('محصول حذف شد.', 'ok');
    if(state.refresh) state.refresh();
  }catch(e){ toast('خطا: ' + e.message, 'err'); }
}

async function openProductForm(id){
  let p = null;
  if(id){
    try{ const r = await apiGet('/products/' + id); p = r.product; }catch(e){ toast('خطا: ' + e.message, 'err'); return; }
  }

  let cats = state.categories && state.categories.length ? state.categories : null;
  if(!cats){
    try{ const r = await apiGet('/categories'); cats = r.categories || []; state.categories = cats; }
    catch(_){ cats = []; }
  }

  const artOptions = ['phone','laptop','headphones','watch','speaker','camera','sneaker','backpack','hoodie','kettle','lamp','book'];
  const artLabels = {phone:'موبایل',laptop:'لپ‌تاپ',headphones:'هدفون',watch:'ساعت',speaker:'اسپیکر',camera:'دوربین',sneaker:'کفش',backpack:'کوله',hoodie:'هودی',kettle:'کتری',lamp:'چراغ',book:'کتاب'};

  const colors = p && p.colors ? p.colors : [{name:'مشکی', hex:'#1f2937'}];
  const specs  = p && p.specs ? p.specs : [];
  const features = p && p.features ? p.features.slice() : [];
  const sizes = p && p.sizes ? p.sizes.slice() : [];
  const images = p && p.images ? p.images.slice() : [];

  const modalEl = document.querySelector('#modal');
  const sheet = document.querySelector('#modalBox');
  if(!modalEl || !sheet){ toast('خطا: مودال پیدا نشد.', 'err'); return; }
  modalLastFocus = document.activeElement;
  sheet.className = 'adm-modal-box adm-prod-sheet';
  modalEl.hidden = false;
  document.documentElement.style.overflow = 'hidden';
  sheet.scrollTop = 0;

  sheet.innerHTML = `
    <div class="adm-modal-head">
      <h3>${id ? 'ویرایش محصول' : 'افزودن محصول جدید'}</h3>
      <button class="adm-iconbtn-sm" data-close type="button" style="margin-inline-start:auto">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>
      </button>
    </div>

    <div class="adm-prod-tabs" role="tablist">
      <button class="adm-prod-tab is-active" data-ptab="basic" type="button">پایه</button>
      <button class="adm-prod-tab" data-ptab="pricing" type="button">قیمت‌گذاری</button>
      <button class="adm-prod-tab" data-ptab="inventory" type="button">انبار</button>
      <button class="adm-prod-tab" data-ptab="media" type="button">تصاویر و ویدئو</button>
      <button class="adm-prod-tab" data-ptab="variants" type="button">تنوع‌ها</button>
      <button class="adm-prod-tab" data-ptab="specs" type="button">مشخصات و ویژگی‌ها</button>
      <button class="adm-prod-tab" data-ptab="seo" type="button">سئو</button>
    </div>

    <div class="adm-prod-body" id="prodTabBody"></div>

    <div class="adm-modal-foot">
      <button class="adm-btn danger" id="prodDeleteBtn" type="button">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>
        حذف محصول
      </button>
      <button class="adm-btn outline" data-close type="button">انصراف</button>
      <button class="adm-btn primary" id="prodSaveBtn" type="button">${id ? 'ذخیره تغییرات' : 'افزودن محصول'}</button>
    </div>
  `;

  const body = sheet.querySelector('#prodTabBody');
  let currentTab = 'basic';

  /* ---- form field registry ---- */
  const F = {
    name: p ? p.name : '',
    sku: p ? (p.sku || '') : '',
    brand: p ? p.brand : '',
    category: p && p.category ? (p.category.slug || String(p.category.id)) : '',
    description: p ? (p.description || '') : '',
    shortDescription: p ? (p.shortDescription || '') : '',
    price: p ? p.price : '',
    purchasePrice: p ? (p.purchasePrice || 0) : 0,
    off: p ? (p.off || 0) : 0,
    stock: p ? p.stock : 0,
    minStock: p ? (p.minStock || 3) : 3,
    weight: p ? (p.weight || 0) : 0,
    dimensions: p ? (p.dimensions || '') : '',
    art: p ? (p.art || 'book') : 'book',
    videoUrl: p ? (p.videoUrl || '') : '',
    warranty: p ? (p.warranty || '') : '',
    metaTitle: p ? (p.metaTitle || '') : '',
    metaDescription: p ? (p.metaDescription || '') : '',
    isActive: p ? !!p.isActive : true,
    images: Array.isArray(p && p.images) ? p.images.slice() : [],
    features: features,
    sizes: sizes,
    colors: colors,
    specs: specs
  };

  /* expose F + repaint utilities globally for the upload handler */
  window.__activeProductF = F;

  /* sync F from the current modal state (called before save) */
  window.__syncActiveF = function(){
    var Fref = window.__activeProductF;
    if(!Fref) return null;
    /* re-read any plain <input data-f> fields that may have changed */
    var s = document.querySelector('#modalBox');
    if(!s) return Fref;
    s.querySelectorAll('[data-f]').forEach(function(el){
      var k = el.dataset.f;
      if(el.type === 'checkbox') Fref[k] = el.checked;
      else Fref[k] = el.value;
    });
    /* make sure images is always a clean array of non-empty strings */
    if(!Array.isArray(Fref.images)) Fref.images = [];
    Fref.images = Fref.images.filter(function(u){
      return u && typeof u === 'string' && u.trim();
    });
    return Fref;
  };
  window.__activeProductRepaint = function(){
    var list = document.querySelector('#imgList');
    if(!list) return;
    list.innerHTML = F.images.map(function(url, idx){
      return '<div class="adm-img-item" data-i="' + idx + '">'
        + '<div class="adm-img-thumb" style="background-image:url(\'' + esc(window.__ASSET__(url)) + '\')"></div>'
        + '<div class="adm-img-url" dir="ltr">' + esc(window.__ASSET__(url)) + '</div>'
        + '<button class="adm-iconbtn-sm danger" data-img-del="' + idx + '" type="button">'
        + '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>'
        + '</button>'
        + '</div>';
    }).join('');
    list.querySelectorAll('[data-img-del]').forEach(function(b){
      b.onclick = function(){
        F.images.splice(+b.dataset.imgDel, 1);
        window.__activeProductRepaint();
      };
    });
  };

  /* also clear on modal close */
  var _closeBtn = document.querySelector('#modal [data-close]');


  function catOptions(selected){
    return '<option value="">انتخاب کنید</option>'
      + cats.map(function(c){
          const val = c.slug || String(c.id);
          const sel = val === selected ? ' selected' : '';
          return '<option value="' + esc(val) + '"' + sel + '>' + esc(c.name) + '</option>';
        }).join('');
  }

  function paintTab(name){
    sheet.querySelectorAll('.adm-prod-tab').forEach(function(t){
      t.classList.toggle('is-active', t.dataset.ptab === name);
    });

    if(name === 'basic'){
      body.innerHTML = `
        <div class="adm-prod-form">
          <div class="adm-grid-2">
            <div class="adm-fld">
              <label>نام محصول <span class="req">*</span></label>
              <input class="adm-input" data-f="name" value="${esc(F.name)}" data-autofocus>
            </div>
            <div class="adm-fld">
              <label>SKU (کد کالا)</label>
              <div style="display:flex;gap:8px">
                <input class="adm-input" data-f="sku" dir="ltr" value="${esc(F.sku)}" placeholder="SKU-XXXX">
                <button class="adm-btn outline" type="button" id="genSku">تولید</button>
              </div>
            </div>
          </div>
          <div class="adm-grid-2">
            <div class="adm-fld">
              <label>برند <span class="req">*</span></label>
              <input class="adm-input" data-f="brand" value="${esc(F.brand)}">
            </div>
            <div class="adm-fld">
              <label>دسته‌بندی <span class="req">*</span></label>
              <select class="adm-select" data-f="category">${catOptions(F.category)}</select>
            </div>
          </div>
          <div class="adm-fld">
            <label>توضیح کوتاه</label>
            <input class="adm-input" data-f="shortDescription" maxlength="320" value="${esc(F.shortDescription)}" placeholder="یک جمله جذاب دربارهٔ محصول">
          </div>
          <div class="adm-fld">
            <label>توضیحات کامل</label>
            <textarea class="adm-textarea" data-f="description" rows="6">${esc(F.description)}</textarea>
          </div>
          <div class="adm-grid-2">
            <div class="adm-fld">
              <label>تصویر پیش‌فرض</label>
              <select class="adm-select" data-f="art">
                ${artOptions.map(function(a){
                  return '<option value="' + a + '"' + (F.art === a ? ' selected' : '') + '>' + artLabels[a] + '</option>';
                }).join('')}
              </select>
            </div>
            <div class="adm-fld">
              <label>وضعیت انتشار</label>
              <div class="adm-prod-switch">
                <label class="adm-pub-toggle">
                  <input type="checkbox" data-f="isActive" ${F.isActive ? 'checked' : ''}>
                  <span class="adm-pub-slider"></span>
                  <span class="adm-pub-label">${F.isActive ? 'منتشرشده' : 'پیش‌نویس'}</span>
                </label>
              </div>
            </div>
          </div>
        </div>
      `;

      const genBtn = body.querySelector('#genSku');
      if(genBtn) genBtn.onclick = async function(){
        genBtn.disabled = true;
        try{
          const r = await apiGet('/products/admin/generate-sku?brand=' + encodeURIComponent(F.brand || 'P'));
          if(r.sku){
            F.sku = r.sku;
            body.querySelector('[data-f="sku"]').value = r.sku;
          }
        }catch(_){}
        finally{ genBtn.disabled = false; }
      };
    }

    else if(name === 'pricing'){
      const finalPrice = Math.round((Number(F.price)||0) * (1 - (Number(F.off)||0)/100) / 1000) * 1000;
      const profit = (Number(F.price)||0) - (Number(F.purchasePrice)||0);
      const profitPct = F.purchasePrice > 0 ? Math.round((profit / F.purchasePrice) * 100) : 0;
      const marginPct = F.price > 0 ? Math.round(((Number(F.price)||0) - (Number(F.purchasePrice)||0)) / (Number(F.price)||1) * 100) : 0;

      body.innerHTML = `
        <div class="adm-prod-form">
          <div class="adm-grid-2">
            <div class="adm-fld">
              <label>قیمت خرید (تومان)</label>
              <input class="adm-input" data-f="purchasePrice" inputmode="numeric" value="${Number(F.purchasePrice)||0}">
              <div class="adm-hint">قیمت تأمین از تأمین‌کننده</div>
            </div>
            <div class="adm-fld">
              <label>قیمت فروش (تومان) <span class="req">*</span></label>
              <input class="adm-input" data-f="price" inputmode="numeric" value="${F.price}" data-autofocus>
            </div>
          </div>
          <div class="adm-grid-2">
            <div class="adm-fld">
              <label>درصد تخفیف (٪)</label>
              <input class="adm-input" data-f="off" inputmode="numeric" value="${F.off}">
              <div class="adm-hint">بین ۰ تا ۹۰</div>
            </div>
            <div class="adm-fld">
              <label>قیمت نهایی پس از تخفیف</label>
              <div class="adm-calc-box" id="calcFinal">${fa(finalPrice)} تومان</div>
            </div>
          </div>

          <div class="adm-price-insights">
            <div class="adm-insight">
              <span>سود هر فروش</span>
              <b style="color:${profit > 0 ? 'var(--adm-ok)' : 'var(--adm-danger)'}">${fa(profit)} تومان</b>
            </div>
            <div class="adm-insight">
              <span>درصد سود نسبت به خرید</span>
              <b style="color:${profit > 0 ? 'var(--adm-ok)' : 'var(--adm-danger)'}">${fa(profitPct)}٪</b>
            </div>
            <div class="adm-insight">
              <span>حاشیه سود</span>
              <b>${fa(marginPct)}٪</b>
            </div>
          </div>
        </div>
      `;

      function recalc(){
        const price = Number(body.querySelector('[data-f="price"]').value) || 0;
        const pp = Number(body.querySelector('[data-f="purchasePrice"]').value) || 0;
        const off = Number(body.querySelector('[data-f="off"]').value) || 0;
        const fp = Math.round(price * (1 - off/100) / 1000) * 1000;
        const pf = price - pp;
        const pct = pp > 0 ? Math.round(pf / pp * 100) : 0;
        const margin = price > 0 ? Math.round((price - pp) / price * 100) : 0;
        body.querySelector('#calcFinal').textContent = fa(fp) + ' تومان';
        const insights = body.querySelectorAll('.adm-insight b');
        if(insights[0]) insights[0].textContent = fa(pf) + ' تومان';
        if(insights[1]) insights[1].textContent = fa(pct) + '٪';
        if(insights[2]) insights[2].textContent = fa(margin) + '٪';
      }
      ['price','purchasePrice','off'].forEach(function(k){
        body.querySelector('[data-f="' + k + '"]').addEventListener('input', recalc);
      });
    }

    else if(name === 'inventory'){
      body.innerHTML = `
        <div class="adm-prod-form">
          <div class="adm-grid-2">
            <div class="adm-fld">
              <label>موجودی فعلی <span class="req">*</span></label>
              <input class="adm-input" data-f="stock" inputmode="numeric" value="${F.stock}" data-autofocus>
            </div>
            <div class="adm-fld">
              <label>حداقل موجودی (هشدار)</label>
              <input class="adm-input" data-f="minStock" inputmode="numeric" value="${F.minStock}">
              <div class="adm-hint">وقتی موجودی به این عدد رسید، هشدار داده می‌شود</div>
            </div>
          </div>
          <div class="adm-grid-3">
            <div class="adm-fld">
              <label>وزن (گرم)</label>
              <input class="adm-input" data-f="weight" inputmode="numeric" value="${F.weight}">
            </div>
            <div class="adm-fld">
              <label>ابعاد (س.ع.ا)</label>
              <input class="adm-input" data-f="dimensions" dir="ltr" value="${esc(F.dimensions)}" placeholder="30x20x10">
            </div>
            <div class="adm-fld">
              <label>گارانتی</label>
              <input class="adm-input" data-f="warranty" value="${esc(F.warranty)}" placeholder="۱۸ ماه گارانتی">
            </div>
          </div>
        </div>
      `;
    }

    else if(name === 'media'){
      body.innerHTML = `
        <div class="adm-prod-form">
          <div class="adm-fld">
            <label>تصاویر محصول</label>
            <div class="adm-hint" style="margin-top:0;margin-bottom:10px">آدرس تصویر را وارد کنید یا از اینترنت کپی کنید.</div>

            <div class="adm-img-list" id="imgList">
              ${F.images.map(function(url, i){
                return '<div class="adm-img-item" data-i="' + i + '">'
                  + '<div class="adm-img-thumb" style="background-image:url(\'' + esc(window.__ASSET__(url)) + '\')"></div>'
                  + '<div class="adm-img-url" dir="ltr">' + esc(window.__ASSET__(url)) + '</div>'
                  + '<button class="adm-iconbtn-sm danger" data-img-del="' + i + '" type="button">'
                  + '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>'
                  + '</button>'
                  + '</div>';
              }).join('')}
            </div>

            <div class="adm-img-add">
              <input class="adm-input" id="newImgUrl" dir="ltr" placeholder="https://example.com/image.jpg">
              <button class="adm-btn primary" id="addImgBtn" type="button">افزودن با آدرس</button>
              <label class="adm-btn outline adm-upload-label" for="prodImgPicker" style="cursor:pointer"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg>آپلود از دستگاه</label><input type="file" id="prodImgPicker" accept="image/*" multiple style="display:none" onchange="window.__handleProdImagePick && window.__handleProdImagePick(this)">
              <input type="file" id="imgFileInput" accept="image/*" multiple style="display:none">
            </div>
            <div class="adm-upload-progress" id="uploadProgress" hidden>
              <div class="adm-upload-bar"><i></i></div>
              <span class="adm-upload-lbl">در حال آپلود...</span>
            </div>
          </div>

          <div class="adm-fld" style="margin-top:20px">
            <label>ویدئوی محصول (آدرس)</label>
            <input class="adm-input" data-f="videoUrl" dir="ltr" value="${esc(F.videoUrl)}" placeholder="https://youtube.com/watch?v=... یا آدرس فایل ویدئو">
          </div>
        </div>
      `;

      function repaintImages(){
        body.querySelector('#imgList').innerHTML = F.images.map(function(url, i){
          return '<div class="adm-img-item" data-i="' + i + '">'
            + '<div class="adm-img-thumb" style="background-image:url(\'' + esc(window.__ASSET__(url)) + '\')"></div>'
            + '<div class="adm-img-url" dir="ltr">' + esc(window.__ASSET__(url)) + '</div>'
            + '<button class="adm-iconbtn-sm danger" data-img-del="' + i + '" type="button">'
            + '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>'
            + '</button>'
            + '</div>';
        }).join('');
        body.querySelectorAll('[data-img-del]').forEach(function(b){
          b.onclick = function(){
            F.images.splice(+b.dataset.imgDel, 1);
            repaintImages();

                                  };
        });
      }
      repaintImages();
      body.querySelectorAll('[data-img-del]').forEach(function(b){
        b.onclick = function(){
          F.images.splice(+b.dataset.imgDel, 1);
          repaintImages();
        };
      });
      body.querySelector('#addImgBtn').onclick = function(){
        const inp = body.querySelector('#newImgUrl');
        const url = inp.value.trim();
        if(!url){ toast('آدرس تصویر را وارد کنید.', 'warn'); return; }
        F.images.push(url);
        inp.value = '';
        repaintImages();
      };
    }

    else if(name === 'variants'){
      body.innerHTML = `
        <div class="adm-prod-form">
          <div class="adm-fld">
            <label>رنگ‌ها</label>
            <div class="adm-color-list" id="colorList">
              ${F.colors.map(function(c, i){
                return '<div class="adm-color-row" data-i="' + i + '">'
                  + '<input type="color" class="adm-color-pick" value="' + esc(c.hex || '#94a3b8') + '" data-color-hex="' + i + '">'
                  + '<input class="adm-input" value="' + esc(c.name || '') + '" data-color-name="' + i + '" placeholder="نام رنگ">'
                  + '<button class="adm-iconbtn-sm danger" data-color-del="' + i + '" type="button">'
                  + '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>'
                  + '</button>'
                  + '</div>';
              }).join('')}
            </div>
            <button class="adm-btn outline sm" id="addColorBtn" type="button" style="margin-top:10px">افزودن رنگ</button>
          </div>

          <div class="adm-fld" style="margin-top:20px">
            <label>سایزها / اندازه‌ها</label>
            <div class="adm-size-list" id="sizeList">
              ${F.sizes.map(function(s, i){
                return '<span class="adm-size-chip">'
                  + '<input value="' + esc(s) + '" data-size="' + i + '" style="border:0;background:transparent;width:60px;outline:0;text-align:center;font-size:13px">'
                  + '<button type="button" data-size-del="' + i + '">×</button>'
                  + '</span>';
              }).join('')}
            </div>
            <div style="display:flex;gap:8px;margin-top:10px">
              <input class="adm-input" id="newSize" placeholder="مثلاً XL یا ۴۲" style="max-width:200px">
              <button class="adm-btn outline" id="addSizeBtn" type="button">افزودن سایز</button>
            </div>
          </div>
        </div>
      `;

      function rebindColors(){
        body.querySelectorAll('[data-color-hex]').forEach(function(el){
          el.oninput = function(){ F.colors[+el.dataset.colorHex].hex = el.value; };
        });
        body.querySelectorAll('[data-color-name]').forEach(function(el){
          el.oninput = function(){ F.colors[+el.dataset.colorName].name = el.value; };
        });
        body.querySelectorAll('[data-color-del]').forEach(function(b){
          b.onclick = function(){
            F.colors.splice(+b.dataset.colorDel, 1);
            paintTab('variants');
          };
        });
      }
      rebindColors();

      body.querySelector('#addColorBtn').onclick = function(){
        F.colors.push({name:'', hex:'#94a3b8'});
        paintTab('variants');
      };

      body.querySelectorAll('[data-size]').forEach(function(el){
        el.oninput = function(){ F.sizes[+el.dataset.size] = el.value; };
      });
      body.querySelectorAll('[data-size-del]').forEach(function(b){
        b.onclick = function(){
          F.sizes.splice(+b.dataset.sizeDel, 1);
          paintTab('variants');
        };
      });
      body.querySelector('#addSizeBtn').onclick = function(){
        const v = body.querySelector('#newSize').value.trim();
        if(!v) return;
        F.sizes.push(v);
        paintTab('variants');
      };
    }

    else if(name === 'specs'){
      body.innerHTML = `
        <div class="adm-prod-form">
          <div class="adm-fld">
            <label>مشخصات فنی</label>
            <div class="adm-spec-list" id="specList">
              ${F.specs.map(function(s, i){
                return '<div class="adm-spec-row">'
                  + '<input class="adm-input" value="' + esc(s.key || '') + '" data-spec-key="' + i + '" placeholder="مثلاً: جنس">'
                  + '<input class="adm-input" value="' + esc(s.value || '') + '" data-spec-val="' + i + '" placeholder="مثلاً: پنبه">'
                  + '<button class="adm-iconbtn-sm danger" data-spec-del="' + i + '" type="button">'
                  + '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>'
                  + '</button>'
                  + '</div>';
              }).join('')}
            </div>
            <button class="adm-btn outline sm" id="addSpecBtn" type="button" style="margin-top:10px">افزودن مشخصه</button>
          </div>

          <div class="adm-fld" style="margin-top:20px">
            <label>ویژگی‌ها</label>
            <div class="adm-feature-list">
              ${F.features.map(function(f, i){
                return '<div class="adm-feature-row">'
                  + '<span class="adm-feature-bullet">•</span>'
                  + '<input class="adm-input" value="' + esc(f) + '" data-feat="' + i + '" placeholder="مثلاً: ضدآب">'
                  + '<button class="adm-iconbtn-sm danger" data-feat-del="' + i + '" type="button">'
                  + '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>'
                  + '</button>'
                  + '</div>';
              }).join('')}
            </div>
            <div style="display:flex;gap:8px;margin-top:10px">
              <input class="adm-input" id="newFeature" placeholder="ویژگی جدید">
              <button class="adm-btn outline" id="addFeatureBtn" type="button">افزودن</button>
            </div>
          </div>
        </div>
      `;

      function rebindSpecs(){
        body.querySelectorAll('[data-spec-key]').forEach(function(el){
          el.oninput = function(){ F.specs[+el.dataset.specKey].key = el.value; };
        });
        body.querySelectorAll('[data-spec-val]').forEach(function(el){
          el.oninput = function(){ F.specs[+el.dataset.specVal].value = el.value; };
        });
        body.querySelectorAll('[data-spec-del]').forEach(function(b){
          b.onclick = function(){
            F.specs.splice(+b.dataset.specDel, 1);
            paintTab('specs');
          };
        });
      }
      rebindSpecs();
      body.querySelector('#addSpecBtn').onclick = function(){
        F.specs.push({key:'', value:''});
        paintTab('specs');
      };

      function rebindFeatures(){
        body.querySelectorAll('[data-feat]').forEach(function(el){
          el.oninput = function(){ F.features[+el.dataset.feat] = el.value; };
        });
        body.querySelectorAll('[data-feat-del]').forEach(function(b){
          b.onclick = function(){
            F.features.splice(+b.dataset.featDel, 1);
            paintTab('specs');
          };
        });
      }
      rebindFeatures();
      body.querySelector('#addFeatureBtn').onclick = function(){
        const v = body.querySelector('#newFeature').value.trim();
        if(!v) return;
        F.features.push(v);
        paintTab('specs');
      };
    }

    else if(name === 'seo'){
      body.innerHTML = `
        <div class="adm-prod-form">
          <div class="adm-fld">
            <label>عنوان سئو (Title)</label>
            <input class="adm-input" data-f="metaTitle" value="${esc(F.metaTitle)}" maxlength="200" placeholder="عنوانی که در گوگل نمایش داده می‌شود">
            <div class="adm-hint">اگر خالی باشد، نام محصول استفاده می‌شود.</div>
          </div>
          <div class="adm-fld">
            <label>توضیح متا (Meta Description)</label>
            <textarea class="adm-textarea" data-f="metaDescription" rows="3" maxlength="320" placeholder="توضیح کوتاه برای موتورهای جستجو">${esc(F.metaDescription)}</textarea>
          </div>
        </div>
      `;
    }

    /* bind text inputs that should reflect into F */
    body.querySelectorAll('[data-f]').forEach(function(el){
      const key = el.dataset.f;
      if(el.type === 'checkbox'){
        el.onchange = function(){ F[key] = el.checked; };
      }else{
        el.oninput = function(){ F[key] = el.value; };
      }
    });
  }

  sheet.querySelectorAll('[data-ptab]').forEach(function(t){
    t.onclick = function(){ currentTab = t.dataset.ptab; paintTab(currentTab); };
  });

  paintTab('basic');

  /* ---- Delete (only when editing) ---- */
  const delBtn = sheet.querySelector('#prodDeleteBtn');
  if(delBtn){
    if(!id){ delBtn.style.display = 'none'; }
    else{
      delBtn.onclick = async function(){
        const ok = await confirmDialog({
          title:'حذف محصول',
          message:'این محصول برای همیشه حذف می‌شود. مطمئنید؟',
          confirmText:'حذف کن'
        });
        if(!ok) return;
        delBtn.disabled = true;
        const oldHtml = delBtn.innerHTML;
        delBtn.innerHTML = 'در حال حذف...';
        try{
          await apiDel('/products/' + id);
          toast('محصول حذف شد.', 'ok');
          closeModal();
          if(state.refresh) state.refresh();
        }catch(e){
          toast('خطا: ' + e.message, 'err');
          delBtn.disabled = false;
          delBtn.innerHTML = oldHtml;
        }
      };
    }
  }

  /* ---- Save ---- */
  const saveBtn = sheet.querySelector('#prodSaveBtn');
  saveBtn.onclick = async function(){
  if(saveBtn.disabled) return;
  saveBtn.disabled = true;
  var oldTxt = saveBtn.textContent;
  saveBtn.textContent = 'در حال ذخیره...';

  try{
    if(typeof window.__syncActiveF === 'function'){ window.__syncActiveF(); }
    var Fcur = window.__activeProductF || F;

    var imgs = Array.isArray(Fcur.images) ? Fcur.images.filter(function(u){ return u && String(u).trim(); }) : [];
    var feats = Array.isArray(Fcur.features) ? Fcur.features.filter(function(x){ return x && String(x).trim(); }) : [];
    var szs = Array.isArray(Fcur.sizes) ? Fcur.sizes.filter(function(x){ return x && String(x).trim(); }) : [];
    var cols = Array.isArray(Fcur.colors) ? Fcur.colors.filter(function(c){ return c && c.name; }) : [];
    var spcs = Array.isArray(Fcur.specs) ? Fcur.specs.filter(function(s){ return s && s.key && s.value; }) : [];

    var payload = {
      name: String(Fcur.name || '').trim(),
      sku: String(Fcur.sku || '').trim() || null,
      brand: String(Fcur.brand || '').trim(),
      category: Fcur.category,
      price: Number(String(Fcur.price || 0).replace(/[^0-9]/g, '')) || 0,
      purchasePrice: Number(String(Fcur.purchasePrice || 0).replace(/[^0-9]/g, '')) || 0,
      off: Math.min(90, Math.max(0, Number(Fcur.off) || 0)),
      stock: Number(String(Fcur.stock || 0).replace(/[^0-9]/g, '')) || 0,
      minStock: Number(String(Fcur.minStock || 0).replace(/[^0-9]/g, '')) || 0,
      weight: Number(String(Fcur.weight || 0).replace(/[^0-9]/g, '')) || 0,
      dimensions: Fcur.dimensions || '',
      art: Fcur.art || 'book',
      description: Fcur.description || '',
      shortDescription: Fcur.shortDescription || '',
      videoUrl: Fcur.videoUrl || '',
      warranty: Fcur.warranty || '',
      metaTitle: Fcur.metaTitle || '',
      metaDescription: Fcur.metaDescription || '',
      images: imgs,
      features: feats,
      sizes: szs,
      colors: cols,
      specs: spcs,
      isActive: !!Fcur.isActive
    };

    console.log('===== SAVE PAYLOAD =====');
    console.log('images:', payload.images);
    console.log('images count:', payload.images.length);
    console.log('=======================');

    if(payload.name.length < 2){ toast('نام محصول را وارد کنید.', 'warn'); throw new Error('validation'); }
    if(!payload.brand){ toast('برند را وارد کنید.', 'warn'); throw new Error('validation'); }
    if(!payload.category){ toast('دسته‌بندی را انتخاب کنید.', 'warn'); throw new Error('validation'); }
    if(!payload.price){ toast('قیمت را وارد کنید.', 'warn'); throw new Error('validation'); }

    var res;
    if(id){
      res = await apiPut('/products/' + id, payload);
    }else{
      res = await apiPost('/products', payload);
    }

    console.log('===== SERVER RESPONSE =====');
    console.log('res.product.images:', res && res.product && res.product.images);
    console.log('===========================');

    toast(id ? 'محصول با موفقیت ذخیره شد.' : 'محصول اضافه شد.', 'ok');
    closeModal();
    if(state.refresh) state.refresh();
  }catch(err){
    if(err.message !== 'validation'){
      console.error('[save-final] error:', err);
      toast('خطا: ' + (err.message || 'نامشخص'), 'err');
    }
    saveBtn.disabled = false;
    saveBtn.textContent = oldTxt;
  }
};
}

/* ================================================================
   PAGE: Categories
   ================================================================ */
async function renderCategories(root){
  root.innerHTML = `
    <div class="adm-sec-head">
      <h2>دسته‌بندی‌ها</h2>
      <div class="adm-sec-actions">
        <button class="adm-btn primary" id="btnNewCat">${ic('plus',18)} دسته‌ی جدید</button>
      </div>
    </div>
    <div class="adm-card"><div class="adm-tbl-wrap"><table class="adm-tbl">
      <thead><tr><th>نام</th><th>نامک</th><th>تعداد محصول</th><th>ترتیب</th><th class="col-actions">عملیات</th></tr></thead>
      <tbody id="catTbody"></tbody>
    </table></div></div>
  `;

  const tbody = $('#catTbody');
  const load = async ()=>{
    tbody.innerHTML = '<tr><td colspan="5"><div class="adm-sk adm-sk-row"></div></td></tr>';
    try{
      const res = await apiGet('/categories?all=true');
      const cats = res.categories || [];
      state.categories = cats;
      if(!cats.length){
        tbody.innerHTML = '<tr><td colspan="5"><div class="adm-empty"><h3>دسته‌ای وجود ندارد</h3></div></td></tr>';
        return;
      }
      tbody.innerHTML = cats.map(c=>`
        <tr>
          <td><b>${esc(c.name)}</b></td>
          <td><span class="adm-bdg">${esc(c.slug||'-')}</span></td>
          <td>${fa(c.productCount||0)}</td>
          <td>${fa(c.order||0)}</td>
          <td class="col-actions"><div class="adm-tbl-actions">
            <button class="adm-iconbtn-sm" data-edit="${c.id}" title="ویرایش">${ic('edit',16)}</button>
            <button class="adm-iconbtn-sm danger" data-del="${c.id}" title="حذف">${ic('trash',16)}</button>
          </div></td>
        </tr>
      `).join('');
      tbody.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>openCatForm(cats.find(x=>x.id===+b.dataset.edit)));
      tbody.querySelectorAll('[data-del]').forEach(b=>b.onclick=()=>deleteCat(+b.dataset.del));
    }catch(e){
      toast('خطا: '+e.message,'err');
    }
  };

  $('#btnNewCat').onclick = ()=>openCatForm(null);
  state.refresh = load;
  load();
}

function openCatForm(cat){
  openModal(`
    <div class="adm-modal-head">
      <h3>${cat?'ویرایش دسته':'دسته‌ی جدید'}</h3>
      <button class="adm-iconbtn-sm" data-close type="button">${ic('x',18)}</button>
    </div>
    <form id="catForm" class="adm-modal-body" novalidate>
      <div class="adm-fld">
        <label>نام <span class="req">*</span></label>
        <input class="adm-input" name="name" value="${esc(cat?cat.name:'')}" data-autofocus>
      </div>
      <div class="adm-grid-2">
        <div class="adm-fld">
          <label>آیکون</label>
          <input class="adm-input" name="icon" value="${esc(cat?cat.icon||'box':'box')}" placeholder="box, phone, book...">
        </div>
        <div class="adm-fld">
          <label>رنگ</label>
          <input class="adm-input" name="color" value="${esc(cat?cat.color||'#3b82f6':'#3b82f6')}" placeholder="#3b82f6">
        </div>
      </div>
      <div class="adm-fld">
        <label>ترتیب نمایش</label>
        <input class="adm-input" name="order" inputmode="numeric" value="${cat?cat.order||0:0}">
      </div>
    </form>
    <div class="adm-modal-foot">
      <button class="adm-btn outline" data-close type="button">انصراف</button>
      <button class="adm-btn primary" id="catSaveBtn" type="button">${cat?'ذخیره':'افزودن'}</button>
    </div>
  `);

  $('#catSaveBtn').onclick = async ()=>{
    const f = $('#catForm');
    const v = n => f.elements[n].value.trim();
    const btn = $('#catSaveBtn');
    btn.disabled = true; const old = btn.textContent; btn.textContent='...';
    const payload = { name:v('name'), icon:v('icon')||'box', color:v('color')||'#3b82f6', order:Number(toEn(v('order')))||0 };
    if(!payload.name){ toast('نام دسته را وارد کنید.','warn'); btn.disabled=false; btn.textContent=old; return; }
    try{
      if(cat) await apiPut('/categories/'+cat.id, payload);
      else    await apiPost('/categories', payload);
      toast(cat?'دسته ویرایش شد.':'دسته اضافه شد.','ok');
      closeModal();
      if(state.refresh) state.refresh();
    }catch(e){ toast('خطا: '+e.message,'err'); }
    finally{ btn.disabled=false; btn.textContent=old; }
  };
}

async function deleteCat(id){
  const ok = await confirmDialog({ title:'حذف دسته', message:'اگر محصولی در این دسته باشد، حذف نمی‌شود.' });
  if(!ok) return;
  try{
    await apiDel('/categories/'+id);
    toast('دسته حذف شد.','ok');
    if(state.refresh) state.refresh();
  }catch(e){ toast('خطا: '+e.message,'err'); }
}

/* ================================================================
   PAGE: Orders
   ================================================================ */
const STATUS_MAP = {
  pending:'در انتظار پرداخت',
  paid:'پرداخت‌شده',
  processing:'در حال پردازش',
  shipped:'ارسال شده',
  delivered:'تحویل شده',
  cancelled:'لغو شده',
  refunded:'بازگشت داده شده'
};
const STATUS_CLS = {
  pending:'warn', paid:'info', processing:'info', shipped:'brand',
  delivered:'ok', cancelled:'danger', refunded:'danger'
};

async function renderOrders(root){
  root.innerHTML = `
    <div class="adm-sec-head">
      <h2>سفارش‌ها</h2>
      <span class="adm-sec-sub" id="ordCount"></span>
      <div class="adm-sec-actions">
        <button class="adm-btn outline sm" id="ordRefresh" type="button">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-3-6.7M21 4v6h-6"/></svg>
          بروزرسانی
        </button>
      </div>
    </div>

    <div class="adm-card">
      <div class="adm-toolbar adm-orders-toolbar">
        <div class="adm-search">
          <span class="adm-search-ic">${ic('search',18)}</span>
          <input id="ordQ" placeholder="کد سفارش یا کد پیگیری..." autocomplete="off">
        </div>
        <div class="adm-search">
          <span class="adm-search-ic">${ic('user',18)}</span>
          <input id="ordCustomer" placeholder="نام یا موبایل مشتری..." autocomplete="off">
        </div>
        <select class="adm-select" id="ordStatus" style="max-width:170px">
          <option value="">همه وضعیت‌ها</option>
          <option value="pending">در انتظار پرداخت</option>
          <option value="paid">پرداخت‌شده</option>
          <option value="processing">در حال پردازش</option>
          <option value="shipped">ارسال‌شده</option>
          <option value="delivered">تحویل‌شده</option>
          <option value="cancelled">لغو‌شده</option>
          <option value="refunded">مرجوعی</option>
        </select>
        <input class="adm-input adm-date" id="ordFrom" type="date" title="از تاریخ">
        <input class="adm-input adm-date" id="ordTo" type="date" title="تا تاریخ">
        <button class="adm-btn outline sm" id="ordReset" type="button">پاک کردن فیلترها</button>
      </div>

      <div class="adm-tbl-wrap">
        <table class="adm-tbl adm-orders-tbl">
          <thead>
            <tr>
              <th>کد سفارش</th>
              <th>مشتری</th>
              <th>تاریخ</th>
              <th>اقلام</th>
              <th>مبلغ کل</th>
              <th>وضعیت</th>
              <th class="col-actions">عملیات</th>
            </tr>
          </thead>
          <tbody id="ordBody"></tbody>
        </table>
      </div>

      <div class="adm-orders-footer" id="ordFooter"></div>
    </div>
  `;

  const STATUS_LABELS = {
    pending:'در انتظار پرداخت', paid:'پرداخت‌شده', processing:'در حال پردازش',
    shipped:'ارسال‌شده', delivered:'تحویل‌شده',
    cancelled:'لغو‌شده', refunded:'مرجوعی'
  };
  const STATUS_CLS = {
    pending:'warn', paid:'info', processing:'info', shipped:'brand',
    delivered:'ok', cancelled:'danger', refunded:'danger'
  };

  const body = root.querySelector('#ordBody');
  const footer = root.querySelector('#ordFooter');
  const cntEl = root.querySelector('#ordCount');

  let page = 1;
  let totalPages = 1;
  let allItems = [];

  async function load(){
    body.innerHTML = '<tr><td colspan="7"><div style="padding:32px;text-align:center;color:var(--adm-muted)">در حال بارگذاری...</div></td></tr>';
    const params = new URLSearchParams();
    params.set('page', page);
    params.set('limit', 20);
    const q = root.querySelector('#ordQ').value.trim();
    const c = root.querySelector('#ordCustomer').value.trim();
    const st = root.querySelector('#ordStatus').value;
    const from = root.querySelector('#ordFrom').value;
    const to = root.querySelector('#ordTo').value;
    if(q) params.set('q', q);
    if(c) params.set('customer', c);
    if(st) params.set('status', st);
    if(from) params.set('from', from);
    if(to) params.set('to', to);

    try{
      const res = await apiGet('/orders?' + params.toString());
      allItems = res.items || [];
      totalPages = res.pagination ? res.pagination.pages : 1;
      cntEl.textContent = fa(res.pagination ? res.pagination.total : 0) + ' سفارش';
      paint();
      paintFooter(res.pagination);
    }catch(e){
      body.innerHTML = '<tr><td colspan="7" style="padding:32px;text-align:center;color:var(--adm-danger)">' + esc(e.message) + '</td></tr>';
    }
  }

  function paint(){
    if(!allItems.length){
      body.innerHTML = '<tr><td colspan="7">'
        + '<div class="adm-empty" style="padding:52px 16px">'
        + '<div class="adm-empty-ic">'
        + '<svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M21 8v8a2 2 0 0 1-1 1.73l-7 4a2 2 0 0 1-2 0l-7-4A2 2 0 0 1 3 16V8a2 2 0 0 1 1-1.73l7-4a2 2 0 0 1 2 0l7 4A2 2 0 0 1 21 8z"/></svg>'
        + '</div>'
        + '<h3>سفارشی پیدا نشد</h3>'
        + '<p>فیلترها را تغییر دهید یا عبارت دیگری را جستجو کنید.</p>'
        + '</div>'
        + '</td></tr>';
      return;
    }

    body.innerHTML = allItems.map(function(o){
      const code = o.trackingCode || '—';
      const customer = o.shippingAddress && o.shippingAddress.name || '—';
      const phone = o.shippingAddress && o.shippingAddress.phone || '';
      const date = (o.createdAt || o.created_at)
        ? new Date(o.createdAt || o.created_at).toLocaleDateString('fa-IR')
        : '—';
      const itemCount = (o.items || []).length;
      const amount = o.totalPrice || o.total_price || 0;
      const stLabel = STATUS_LABELS[o.status] || o.status;
      const stCls = STATUS_CLS[o.status] || '';
      const hasNote = o.internalNote || o.customerNote;
      const hasShipment = o.shipmentTracking;

      return '<tr data-order-row="' + o.id + '">'
        + '<td><div class="adm-order-code">'
        + '<b dir="ltr">' + esc(code) + '</b>'
        + (hasShipment ? '<span class="adm-order-sub" dir="ltr" title="کد رهگیری مرسوله">' + esc(hasShipment) + '</span>' : '')
        + (hasNote ? '<span class="adm-order-note-dot" title="یادداشت دارد"></span>' : '')
        + '</div></td>'
        + '<td><div class="adm-order-cust">'
        + '<b>' + esc(customer) + '</b>'
        + (phone ? '<span dir="ltr">' + esc(phone) + '</span>' : '')
        + '</div></td>'
        + '<td>' + esc(date) + '</td>'
        + '<td><span class="adm-bdg">' + fa(itemCount) + ' قلم</span></td>'
        + '<td><b>' + fa(amount) + '</b> <small style="color:var(--adm-muted)">تومان</small></td>'
        + '<td><span class="adm-bdg ' + stCls + '">' + esc(stLabel) + '</span></td>'
        + '<td class="col-actions"><div class="adm-tbl-actions">'
        + '<button class="adm-iconbtn-sm" data-view="' + o.id + '" title="مشاهده جزئیات">'
        + '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z"/><circle cx="12" cy="12" r="3"/></svg>'
        + '</button>'
        + '<button class="adm-iconbtn-sm" data-invoice="' + o.id + '" title="فاکتور">'
        + '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2h9l5 5v15H6z"/><path d="M14 2v6h6M9 13h6M9 17h4"/></svg>'
        + '</button>'
        + '</div></td>'
        + '</tr>';
    }).join('');

    body.querySelectorAll('[data-view]').forEach(function(b){
      b.onclick = function(){ viewOrder(+b.dataset.view); };
    });
    body.querySelectorAll('[data-invoice]').forEach(function(b){
      b.onclick = function(){ openInvoice(+b.dataset.invoice); };
    });
  }

  function paintFooter(p){
    if(!p || p.pages <= 1){ footer.innerHTML = ''; return; }
    let html = '<div class="adm-orders-pager">';
    html += '<button class="adm-btn ghost sm" ' + (p.page <= 1 ? 'disabled' : '') + ' data-page="prev">قبلی</button>';
    html += '<span class="adm-orders-pageinfo">صفحه ' + fa(p.page) + ' از ' + fa(p.pages) + '</span>';
    html += '<button class="adm-btn ghost sm" ' + (p.page >= p.pages ? 'disabled' : '') + ' data-page="next">بعدی</button>';
    html += '</div>';
    footer.innerHTML = html;
    footer.querySelectorAll('[data-page]').forEach(function(b){
      b.onclick = function(){
        if(b.dataset.page === 'prev' && page > 1) page--;
        if(b.dataset.page === 'next' && page < totalPages) page++;
        load();
      };
    });
  }

  /* filter events */
  let timer;
  root.querySelector('#ordQ').addEventListener('input', function(){ clearTimeout(timer); timer = setTimeout(function(){ page = 1; load(); }, 400); });
  root.querySelector('#ordCustomer').addEventListener('input', function(){ clearTimeout(timer); timer = setTimeout(function(){ page = 1; load(); }, 400); });
  root.querySelector('#ordStatus').addEventListener('change', function(){ page = 1; load(); });
  root.querySelector('#ordFrom').addEventListener('change', function(){ page = 1; load(); });
  root.querySelector('#ordTo').addEventListener('change', function(){ page = 1; load(); });
  root.querySelector('#ordReset').addEventListener('click', function(){
    root.querySelector('#ordQ').value = '';
    root.querySelector('#ordCustomer').value = '';
    root.querySelector('#ordStatus').value = '';
    root.querySelector('#ordFrom').value = '';
    root.querySelector('#ordTo').value = '';
    page = 1; load();
  });
  root.querySelector('#ordRefresh').addEventListener('click', load);

  state.refresh = load;
  load();
}

async function viewOrder(id){
  let o;
  try{
    const res = await apiGet('/orders/' + id);
    o = res.order;
  }catch(e){ toast('خطا: ' + e.message, 'err'); return; }

  const STATUS_LABELS = {
    pending:'در انتظار پرداخت', paid:'پرداخت‌شده', processing:'در حال پردازش',
    shipped:'ارسال‌شده', delivered:'تحویل‌شده',
    cancelled:'لغو‌شده', refunded:'مرجوعی'
  };
  const STATUS_CLS = {
    pending:'warn', paid:'info', processing:'info', shipped:'brand',
    delivered:'ok', cancelled:'danger', refunded:'danger'
  };

  const fmtDate = d => d ? new Date(d).toLocaleString('fa-IR') : '—';
  const money = n => fa(Math.round(Number(n)||0)) + ' تومان';

  function render(o){
    const stLabel = STATUS_LABELS[o.status] || o.status;
    const stCls = STATUS_CLS[o.status] || '';
    const sa = o.shippingAddress || {};

    return `
      <div class="adm-modal-head">
        <h3>سفارش <b dir="ltr">${esc(o.trackingCode)}</b></h3>
        <span class="adm-bdg ${stCls}">${esc(stLabel)}</span>
        <button class="adm-iconbtn-sm" data-close type="button" style="margin-inline-start:auto">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>
        </button>
      </div>

      <div class="adm-order-tabs" role="tablist">
        <button class="adm-order-tab is-active" data-otab="summary" type="button">خلاصه</button>
        <button class="adm-order-tab" data-otab="items" type="button">اقلام</button>
        <button class="adm-order-tab" data-otab="shipment" type="button">ارسال</button>
        <button class="adm-order-tab" data-otab="financial" type="button">مالی</button>
        <button class="adm-order-tab" data-otab="notes" type="button">یادداشت‌ها</button>
      </div>

      <div class="adm-order-body" id="ordTabBody"></div>

      <div class="adm-order-actions-bar">
        <div class="adm-order-actions-left">
          <button class="adm-btn outline sm" data-action="invoice" type="button">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2h9l5 5v15H6z"/><path d="M14 2v6h6M9 13h6M9 17h4"/></svg>
            فاکتور
          </button>
        </div>
        <div class="adm-order-actions-right">
          ${!['delivered','cancelled','refunded'].includes(o.status) ? `
            <button class="adm-btn outline sm" data-action="cancel" type="button">لغو سفارش</button>
          ` : ''}
          ${!['refunded','cancelled'].includes(o.status) ? `
            <button class="adm-btn outline sm is-danger" data-action="return" type="button">مرجوع کردن</button>
            <button class="adm-btn danger sm" data-action="refund" type="button">بازپرداخت</button>
          ` : ''}
        </div>
      </div>
    `;
  }

  const sheet = document.querySelector('#modalBox');
  modalLastFocus = document.activeElement;
  sheet.className = 'adm-modal-box adm-order-sheet';
  const modalEl = document.querySelector('#modal');
  if(modalEl){ modalEl.hidden = false; document.documentElement.style.overflow = 'hidden'; }
  sheet.scrollTop = 0;
  sheet.innerHTML = render(o);

  const bodyEl = sheet.querySelector('#ordTabBody');

  function paintTab(name){
    sheet.querySelectorAll('.adm-order-tab').forEach(function(t){
      t.classList.toggle('is-active', t.dataset.otab === name);
    });

    const sa = o.shippingAddress || {};

    if(name === 'summary'){
      bodyEl.innerHTML = `
        <div class="adm-order-summary">
          <div class="adm-order-summary-grid">
            <div class="adm-order-field">
              <label>مشتری</label>
              <div>${esc(sa.name || '—')}</div>
            </div>
            <div class="adm-order-field">
              <label>موبایل</label>
              <div dir="ltr">${esc(sa.phone || '—')}</div>
            </div>
            <div class="adm-order-field">
              <label>تاریخ ثبت</label>
              <div>${esc(fmtDate(o.createdAt))}</div>
            </div>
            <div class="adm-order-field">
              <label>روش پرداخت</label>
              <div>${o.paymentMethod === 'cod' ? 'پرداخت در محل' : 'پرداخت آنلاین'}</div>
            </div>
            <div class="adm-order-field adm-field-wide">
              <label>نشانی</label>
              <div>${esc([sa.province, sa.city, sa.street].filter(Boolean).join('، ')) || '—'}</div>
            </div>
            ${sa.postalCode ? '<div class="adm-order-field"><label>کد پستی</label><div dir="ltr">' + esc(sa.postalCode) + '</div></div>' : ''}
          </div>

          <div class="adm-order-status-changer">
            <label>تغییر وضعیت سفارش</label>
            <div class="adm-status-btns">
              ${['pending','paid','processing','shipped','delivered','cancelled'].map(function(st){
                const active = o.status === st;
                return '<button class="adm-status-btn ' + (active ? 'is-active ' : '') + (STATUS_CLS[st]||'') + '" data-set-status="' + st + '" type="button">' + STATUS_LABELS[st] + '</button>';
              }).join('')}
            </div>
          </div>
        </div>
      `;

      bodyEl.querySelectorAll('[data-set-status]').forEach(function(b){
        b.onclick = function(){ updateStatus(o.id, b.dataset.setStatus, reload); };
      });
    }

    else if(name === 'items'){
      if(!o.items || !o.items.length){
        bodyEl.innerHTML = '<div class="adm-empty" style="padding:40px 16px"><h3>قلمی یافت نشد</h3></div>';
        return;
      }
      bodyEl.innerHTML = `
        <div class="adm-order-items">
          ${o.items.map(function(it){
            const colorChip = it.color
              ? '<span class="adm-item-color"><i style="background:' + esc(it.color.hex) + '"></i>' + esc(it.color.name) + '</span>'
              : '';
            return '<div class="adm-order-item">'
              + '<div class="adm-order-item-thumb">' + ic(it.art || 'box', 22) + '</div>'
              + '<div class="adm-order-item-info">'
              + '<b>' + esc(it.name) + '</b>'
              + colorChip
              + '</div>'
              + '<div class="adm-order-item-qty">' + fa(it.qty) + ' × ' + fa(it.price) + '</div>'
              + '<div class="adm-order-item-total">' + money(it.lineTotal) + '</div>'
              + '</div>';
          }).join('')}
        </div>
      `;
    }

    else if(name === 'shipment'){
      const carriers = ['پست پیشتاز','پست سفارشی','تیپاکس','چاپار','آرامکس','باربری','پیک موتوری','سایر'];
      bodyEl.innerHTML = `
        <div class="adm-order-form">
          <div class="adm-grid-2">
            <div class="adm-fld">
              <label>شرکت حمل و نقل</label>
              <select class="adm-select" id="ordCarrier">
                <option value="">انتخاب کنید</option>
                ${carriers.map(function(c){
                  return '<option ' + (o.shipmentCarrier === c ? 'selected' : '') + '>' + c + '</option>';
                }).join('')}
              </select>
            </div>
            <div class="adm-fld">
              <label>کد رهگیری مرسوله</label>
              <input class="adm-input" id="ordTrack" dir="ltr" placeholder="مثال: 1234567890123" value="${esc(o.shipmentTracking || '')}">
            </div>
          </div>
          <div class="adm-fld">
            <button class="adm-btn primary" id="ordSaveShip" type="button">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>
              ذخیره اطلاعات ارسال
            </button>
            <div class="adm-hint" style="margin-top:10px">با ثبت کد رهگیری، وضعیت سفارش به «ارسال‌شده» تغییر می‌کند.</div>
          </div>
        </div>
      `;

      bodyEl.querySelector('#ordSaveShip').onclick = async function(){
        const tracking = bodyEl.querySelector('#ordTrack').value.trim();
        const carrier = bodyEl.querySelector('#ordCarrier').value;
        try{
          await apiPatch('/orders/' + o.id + '/shipment', { shipmentTracking: tracking, shipmentCarrier: carrier });
          toast('اطلاعات ارسال ذخیره شد.', 'ok');
          reload();
        }catch(e){ toast('خطا: ' + e.message, 'err'); }
      };
    }

    else if(name === 'financial'){
      bodyEl.innerHTML = `
        <div class="adm-order-form">
          <div class="adm-grid-3">
            <div class="adm-fld">
              <label>هزینه ارسال (تومان)</label>
              <input class="adm-input" id="ordShip" inputmode="numeric" value="${Number(o.shippingPrice)||0}">
            </div>
            <div class="adm-fld">
              <label>مالیات (تومان)</label>
              <input class="adm-input" id="ordTax" inputmode="numeric" value="${Number(o.tax)||0}">
            </div>
            <div class="adm-fld">
              <label>تخفیف (تومان)</label>
              <input class="adm-input" id="ordDisc" inputmode="numeric" value="${Number(o.discountAmount)||0}">
            </div>
          </div>

          <div class="adm-order-price-box">
            <div class="adm-price-row"><span>جمع کالاها</span><b>${money(o.itemsPrice)}</b></div>
            <div class="adm-price-row"><span>هزینه ارسال</span><b id="prevShip">${money(o.shippingPrice)}</b></div>
            <div class="adm-price-row"><span>مالیات</span><b id="prevTax">${money(o.tax)}</b></div>
            <div class="adm-price-row is-disc"><span>تخفیف</span><b id="prevDisc">- ${money(o.discountAmount)}</b></div>
            <div class="adm-price-row is-total"><span>مبلغ قابل پرداخت</span><b id="prevTotal">${money(o.totalPrice)}</b></div>
          </div>

          <div class="adm-fld">
            <button class="adm-btn primary" id="ordSaveFin" type="button">ذخیره اطلاعات مالی</button>
          </div>
        </div>
      `;

      function recalc(){
        const ship = Number(bodyEl.querySelector('#ordShip').value) || 0;
        const tax  = Number(bodyEl.querySelector('#ordTax').value) || 0;
        const disc = Number(bodyEl.querySelector('#ordDisc').value) || 0;
        const total = Math.max(0, Number(o.itemsPrice||0) + ship + tax - disc);
        bodyEl.querySelector('#prevShip').textContent = money(ship);
        bodyEl.querySelector('#prevTax').textContent = money(tax);
        bodyEl.querySelector('#prevDisc').textContent = '- ' + money(disc);
        bodyEl.querySelector('#prevTotal').textContent = money(total);
      }
      ['ordShip','ordTax','ordDisc'].forEach(function(id){
        bodyEl.querySelector('#' + id).addEventListener('input', recalc);
      });

      bodyEl.querySelector('#ordSaveFin').onclick = async function(){
        const ship = Number(bodyEl.querySelector('#ordShip').value) || 0;
        const tax  = Number(bodyEl.querySelector('#ordTax').value) || 0;
        const disc = Number(bodyEl.querySelector('#ordDisc').value) || 0;
        try{
          await apiPatch('/orders/' + o.id + '/financial', { shippingCost: ship, tax: tax, discount: disc });
          toast('اطلاعات مالی ذخیره شد.', 'ok');
          reload();
        }catch(e){ toast('خطا: ' + e.message, 'err'); }
      };
    }

    else if(name === 'notes'){
      bodyEl.innerHTML = `
        <div class="adm-order-form">
          <div class="adm-fld">
            <label>یادداشت داخلی <span class="adm-hint" style="font-weight:400">(فقط برای ادمین‌ها)</span></label>
            <textarea class="adm-textarea" id="ordInternal" placeholder="مثلاً: مشتری درخواست تماس قبل از ارسال داشت.">${esc(o.internalNote || '')}</textarea>
          </div>
          <div class="adm-fld">
            <label>یادداشت برای مشتری</label>
            <textarea class="adm-textarea" id="ordCustomer" placeholder="این یادداشت به مشتری نشان داده می‌شود.">${esc(o.customerNote || '')}</textarea>
          </div>
          <div class="adm-fld">
            <button class="adm-btn primary" id="ordSaveNotes" type="button">ذخیره یادداشت‌ها</button>
          </div>

          ${o.returnReason ? `
            <div class="adm-order-alert is-warn">
              <b>دلیل مرجوعی:</b>
              <p>${esc(o.returnReason)}</p>
            </div>
          ` : ''}
          ${o.refundNote ? `
            <div class="adm-order-alert is-danger">
              <b>یادداشت بازپرداخت:</b>
              <p>${esc(o.refundNote)}</p>
              <div class="adm-hint" style="margin-top:6px">مبلغ بازپرداخت: ${money(o.refundedAmount)}</div>
            </div>
          ` : ''}
        </div>
      `;

      bodyEl.querySelector('#ordSaveNotes').onclick = async function(){
        try{
          await apiPatch('/orders/' + o.id + '/notes', {
            internalNote: bodyEl.querySelector('#ordInternal').value,
            customerNote: bodyEl.querySelector('#ordCustomer').value
          });
          toast('یادداشت‌ها ذخیره شد.', 'ok');
          reload();
        }catch(e){ toast('خطا: ' + e.message, 'err'); }
      };
    }
  }

  async function reload(){
    try{
      const res = await apiGet('/orders/' + o.id);
      o = res.order;
      sheet.innerHTML = render(o);
      sheet.classList.add('adm-order-sheet');
      bind();
      paintTab(currentTab);
    }catch(e){ toast('خطا: ' + e.message, 'err'); }
  }

  let currentTab = 'summary';

  function bind(){
    const sh = sheet;
    sh.querySelector('[data-close]').onclick = closeModal;
    sh.querySelectorAll('[data-otab]').forEach(function(t){
      t.onclick = function(){ currentTab = t.dataset.otab; paintTab(currentTab); };
    });
    sh.querySelector('[data-action="invoice"]').onclick = function(){ openInvoice(o.id); };
    const cancelBtn = sh.querySelector('[data-action="cancel"]');
    if(cancelBtn) cancelBtn.onclick = function(){
      confirmDialog({ title:'لغو سفارش', message:'این سفارش لغو می‌شود. مطمئنید؟', confirmText:'لغو سفارش' })
        .then(function(ok){ if(ok) cancelOrder(o.id, reload); });
    };
    const retBtn = sh.querySelector('[data-action="return"]');
    if(retBtn) retBtn.onclick = function(){ openReturnDialog(o, reload); };
    const refBtn = sh.querySelector('[data-action="refund"]');
    if(refBtn) refBtn.onclick = function(){ openRefundDialog(o, reload); };
  }

  bind();
  paintTab('summary');
}

async function updateStatus(id, status, onDone){
  try{
    await apiPatch('/orders/' + id + '/status', { status: status });
    toast('وضعیت تغییر کرد.', 'ok');
    if(onDone) onDone();
  }catch(e){ toast('خطا: ' + e.message, 'err'); }
}

async function cancelOrder(id, onDone){
  try{
    await apiPatch('/orders/' + id + '/cancel');
    toast('سفارش لغو شد.', 'ok');
    if(onDone) onDone();
  }catch(e){ toast('خطا: ' + e.message, 'err'); }
}

function openReturnDialog(o, onDone){
  openModal(`
    <div class="adm-modal-head">
      <h3>مرجوع کردن سفارش</h3>
      <button class="adm-iconbtn-sm" data-close type="button">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>
      </button>
    </div>
    <div class="adm-modal-body">
      <p class="adm-hint" style="margin-top:0">با تأیید این عملیات، موجودی کالاها به انبار بازمی‌گردد و وضعیت سفارش «مرجوعی» می‌شود.</p>
      <div class="adm-fld">
        <label>دلیل مرجوعی <span class="req">*</span></label>
        <textarea class="adm-textarea" id="retReason" data-autofocus placeholder="مثلاً: کالا با توضیحات مطابقت نداشت"></textarea>
      </div>
    </div>
    <div class="adm-modal-foot">
      <button class="adm-btn outline" data-close type="button">انصراف</button>
      <button class="adm-btn danger" id="retConfirm" type="button">ثبت مرجوعی</button>
    </div>
  `);

  document.querySelector('#retConfirm').onclick = async function(){
    const reason = document.querySelector('#retReason').value.trim();
    if(reason.length < 3){ toast('دلیل مرجوعی را وارد کنید.', 'warn'); return; }
    try{
      await apiPost('/orders/' + o.id + '/return', { reason: reason });
      toast('سفارش مرجوع شد.', 'ok');
      closeModal();
      if(onDone) onDone();
    }catch(e){ toast('خطا: ' + e.message, 'err'); }
  };
}

function openRefundDialog(o, onDone){
  const total = o.totalPrice || o.total_price || 0;
  openModal(`
    <div class="adm-modal-head">
      <h3>بازپرداخت وجه</h3>
      <button class="adm-iconbtn-sm" data-close type="button">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>
      </button>
    </div>
    <div class="adm-modal-body">
      <div class="adm-fld">
        <label>مبلغ بازپرداخت (تومان) <span class="req">*</span></label>
        <input class="adm-input" id="refAmount" inputmode="numeric" value="${total}" data-autofocus>
      </div>
      <div class="adm-fld">
        <label>یادداشت بازپرداخت</label>
        <textarea class="adm-textarea" id="refNote" placeholder="مثلاً: بازپرداخت به حساب بانکی مشتری"></textarea>
      </div>
      <div class="adm-hint">مبلغ کل سفارش: ${fa(total)} تومان</div>
    </div>
    <div class="adm-modal-foot">
      <button class="adm-btn outline" data-close type="button">انصراف</button>
      <button class="adm-btn danger" id="refConfirm" type="button">تأیید بازپرداخت</button>
    </div>
  `);

  document.querySelector('#refConfirm').onclick = async function(){
    const amount = Number(String(document.querySelector('#refAmount').value).replace(/[^\d]/g, '')) || 0;
    const note = document.querySelector('#refNote').value.trim();
    if(amount <= 0){ toast('مبلغ بازپرداخت را وارد کنید.', 'warn'); return; }
    try{
      await apiPost('/orders/' + o.id + '/refund', { amount: amount, note: note });
      toast('بازپرداخت ثبت شد.', 'ok');
      closeModal();
      if(onDone) onDone();
    }catch(e){ toast('خطا: ' + e.message, 'err'); }
  };
}

/* ================================================================
   Invoice — print + PDF
   ================================================================ */
async function openInvoice(id){
  let o;
  try{
    const res = await apiGet('/orders/' + id);
    o = res.order;
  }catch(e){ toast('خطا: ' + e.message, 'err'); return; }

  const money = n => fa(Math.round(Number(n)||0)) + ' تومان';
  const fmtDate = d => d ? new Date(d).toLocaleString('fa-IR') : '—';
  const sa = o.shippingAddress || {};

  const STATUS_LABELS = {
    pending:'در انتظار پرداخت', paid:'پرداخت‌شده', processing:'در حال پردازش',
    shipped:'ارسال‌شده', delivered:'تحویل‌شده',
    cancelled:'لغو‌شده', refunded:'مرجوعی'
  };

  const itemsHTML = (o.items || []).map(function(it){
    const colorInfo = it.color ? ' (' + it.color.name + ')' : '';
    return '<tr>'
      + '<td>' + fa(it.qty) + '</td>'
      + '<td>' + esc(it.name) + esc(colorInfo) + '</td>'
      + '<td>' + fa(it.price) + '</td>'
      + '<td>' + fa(it.lineTotal) + '</td>'
      + '</tr>';
  }).join('');

  const invoiceHTML = `
    <div class="inv" id="invoicePrint">
      <div class="inv-head">
        <div class="inv-brand">
          <div class="inv-brand-mark">
            <svg width="42" height="42" viewBox="0 0 64 64">
              <defs><linearGradient id="invWine" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#9B2447"/><stop offset="1" stop-color="#4A0F20"/></linearGradient></defs>
              <rect x="3" y="3" width="58" height="58" rx="18" fill="url(#invWine)"/>
              <path d="M20 27 L44 27 L41.5 47 L22.5 47 Z" fill="none" stroke="#E2C88C" stroke-width="2.4" stroke-linejoin="round"/>
              <path d="M24.5 27 C24.5 18.8 39.5 18.8 39.5 27" fill="none" stroke="#E2C88C" stroke-width="2.4" stroke-linecap="round"/>
            </svg>
          </div>
          <div>
            <div class="inv-brand-name">زحمتکش مارکت</div>
            <div class="inv-brand-sub">فروشگاه اینترنتی</div>
          </div>
        </div>
        <div class="inv-meta">
          <h2>فاکتور فروش</h2>
          <div class="inv-meta-line"><span>کد سفارش:</span><b dir="ltr">${esc(o.trackingCode)}</b></div>
          <div class="inv-meta-line"><span>تاریخ:</span><b>${esc(fmtDate(o.createdAt))}</b></div>
          <div class="inv-meta-line"><span>وضعیت:</span><b>${esc(STATUS_LABELS[o.status] || o.status)}</b></div>
        </div>
      </div>

      <div class="inv-customers">
        <div class="inv-cust-block">
          <div class="inv-cust-title">اطلاعات مشتری</div>
          <div class="inv-cust-row"><span>نام:</span><b>${esc(sa.name || '—')}</b></div>
          <div class="inv-cust-row"><span>موبایل:</span><b dir="ltr">${esc(sa.phone || '—')}</b></div>
          <div class="inv-cust-row"><span>نشانی:</span><b>${esc([sa.province, sa.city, sa.street].filter(Boolean).join('، ')) || '—'}</b></div>
          ${sa.postalCode ? '<div class="inv-cust-row"><span>کد پستی:</span><b dir="ltr">' + esc(sa.postalCode) + '</b></div>' : ''}
        </div>
        ${o.shipmentTracking ? `
          <div class="inv-cust-block">
            <div class="inv-cust-title">اطلاعات ارسال</div>
            ${o.shipmentCarrier ? '<div class="inv-cust-row"><span>شرکت حمل:</span><b>' + esc(o.shipmentCarrier) + '</b></div>' : ''}
            <div class="inv-cust-row"><span>کد رهگیری:</span><b dir="ltr">${esc(o.shipmentTracking)}</b></div>
          </div>
        ` : ''}
      </div>

      <table class="inv-table">
        <thead>
          <tr>
            <th style="width:60px">تعداد</th>
            <th>شرح کالا</th>
            <th style="width:120px">قیمت واحد (تومان)</th>
            <th style="width:130px">جمع (تومان)</th>
          </tr>
        </thead>
        <tbody>${itemsHTML}</tbody>
      </table>

      <div class="inv-totals">
        <div class="inv-total-row"><span>جمع کالاها:</span><b>${money(o.itemsPrice)}</b></div>
        <div class="inv-total-row"><span>هزینه ارسال:</span><b>${money(o.shippingPrice)}</b></div>
        ${Number(o.tax) > 0 ? '<div class="inv-total-row"><span>مالیات:</span><b>' + money(o.tax) + '</b></div>' : ''}
        ${Number(o.discountAmount) > 0 ? '<div class="inv-total-row is-disc"><span>تخفیف:</span><b>- ' + money(o.discountAmount) + '</b></div>' : ''}
        <div class="inv-total-row is-grand"><span>مبلغ قابل پرداخت:</span><b>${money(o.totalPrice)}</b></div>
      </div>

      <div class="inv-foot">
        <div>با تشکر از خرید شما 🌹</div>
        <div>zahmatkesh-market.ir</div>
      </div>
    </div>
  `;

  openModal(`
    <div class="adm-modal-head">
      <h3>فاکتور سفارش <b dir="ltr">${esc(o.trackingCode)}</b></h3>
      <button class="adm-iconbtn-sm" data-close type="button" style="margin-inline-start:auto">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>
      </button>
    </div>
    <div class="adm-modal-body" style="padding:0">
      ${invoiceHTML}
    </div>
    <div class="adm-modal-foot">
      <button class="adm-btn outline" data-close type="button">بستن</button>
      <button class="adm-btn outline" id="invPrint" type="button">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2M6 14h12v8H6z"/></svg>
        چاپ
      </button>
      <button class="adm-btn primary" id="invPdf" type="button">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg>
        دانلود PDF
      </button>
    </div>
  `, 'wide');

  document.querySelector('#invPrint').onclick = function(){
    const node = document.querySelector('#invoicePrint');
    if(!node) return;
    const w = window.open('', '_blank', 'width=900,height=700');
    w.document.write('<!doctype html><html dir="rtl"><head><meta charset="utf-8"><title>فاکتور ' + esc(o.trackingCode) + '</title></head><body style="margin:0;background:#fff">' + node.outerHTML + '</body></html>');
    w.document.close();
    /* wait for fonts */
    setTimeout(function(){ w.focus(); w.print(); w.close(); }, 400);
  };

  document.querySelector('#invPdf').onclick = async function(){
    const btn = this;
    btn.disabled = true; const old = btn.innerHTML;
    btn.innerHTML = 'در حال آماده‌سازی...';
    try{
      if(!window.html2pdf){
        await new Promise(function(resolve, reject){
          const s = document.createElement('script');
          s.src = 'https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js';
          s.onload = resolve;
          s.onerror = reject;
          document.head.appendChild(s);
        });
      }
      const node = document.querySelector('#invoicePrint');
      await window.html2pdf().set({
        margin: 10,
        filename: 'invoice-' + o.trackingCode + '.pdf',
        image: { type:'jpeg', quality: 0.95 },
        html2canvas: { scale: 2, useCORS: true, backgroundColor: '#ffffff' },
        jsPDF: { unit:'mm', format:'a4', orientation:'portrait' }
      }).from(node).save();
      toast('فاکتور دانلود شد.', 'ok');
    }catch(e){
      toast('خطا: ' + e.message, 'err');
    }finally{
      btn.disabled = false; btn.innerHTML = old;
    }
  };
}

/* ================================================================
   PAGE: Users
   ================================================================ */
async function renderUsers(root){
  root.innerHTML = `
    <div class="adm-sec-head"><h2>کاربران</h2><span class="adm-sec-sub" id="usrCount"></span></div>
    <div class="adm-card">
      <div class="adm-toolbar">
        <div class="adm-search">
          <span class="adm-search-ic">${ic('search',18)}</span>
          <input id="usrSearch" placeholder="جستجو..." autocomplete="off">
        </div>
      </div>
      <div class="adm-tbl-wrap"><table class="adm-tbl">
        <thead><tr><th>نام</th><th>ایمیل</th><th>موبایل</th><th>نقش</th><th>وضعیت</th><th class="col-actions">عملیات</th></tr></thead>
        <tbody id="usrTbody"></tbody>
      </table></div>
    </div>
  `;

  const tbody = $('#usrTbody');
  let all = [];

  const renderRows = list=>{
    if(!list.length){
      tbody.innerHTML = '<tr><td colspan="6"><div class="adm-empty"><h3>کاربری یافت نشد</h3></div></td></tr>';
      return;
    }
    tbody.innerHTML = list.map(u=>`
      <tr>
        <td><b>${esc(u.name)}</b></td>
        <td dir="ltr">${esc(u.email)}</td>
        <td dir="ltr">${esc(u.phone)}</td>
        <td>${u.role==='admin'?'<span class="adm-bdg brand">ادمین</span>':'<span class="adm-bdg">کاربر</span>'}</td>
        <td>${u.isActive?'<span class="adm-bdg ok">فعال</span>':'<span class="adm-bdg danger">غیرفعال</span>'}</td>
        <td class="col-actions"><div class="adm-tbl-actions">
          <button class="adm-iconbtn-sm" data-role="${u.id}" data-cur="${u.role}" title="تغییر نقش">${ic('user',16)}</button>
          <button class="adm-iconbtn-sm" data-toggle="${u.id}" title="فعال/غیرفعال">${u.isActive?ic('toggleOn',16):ic('toggleOff',16)}</button>
          <button class="adm-iconbtn-sm danger" data-del="${u.id}" title="حذف">${ic('trash',16)}</button>
        </div></td>
      </tr>
    `).join('');
    tbody.querySelectorAll('[data-role]').forEach(b=>b.onclick=()=>changeRole(+b.dataset.role, b.dataset.cur));
    tbody.querySelectorAll('[data-toggle]').forEach(b=>b.onclick=()=>toggleUser(+b.dataset.toggle));
    tbody.querySelectorAll('[data-del]').forEach(b=>b.onclick=()=>deleteUser(+b.dataset.del));
  };

  const load = async ()=>{
    tbody.innerHTML = '<tr><td colspan="6"><div class="adm-sk adm-sk-row"></div></td></tr>';
    try{
      const res = await apiGet('/users?limit=100');
      all = res.items || [];
      $('#usrCount').textContent = fa(all.length) + ' کاربر';
      renderRows(all);
    }catch(e){ toast('خطا: '+e.message,'err'); }
  };
  $('#usrSearch').addEventListener('input', e=>{
    const q = e.target.value.trim().toLowerCase();
    if(!q){ renderRows(all); return; }
    renderRows(all.filter(u=>(u.name+' '+u.email+' '+u.phone).toLowerCase().includes(q)));
  });

  state.refresh = load;
  load();
}

async function changeRole(id, cur){
  const next = cur==='admin' ? 'user' : 'admin';
  const ok = await confirmDialog({
    title: next==='admin'?'ارتقا به ادمین':'حذف دسترسی ادمین',
    message:'نقش کاربر تغییر می‌کند. مطمئنید؟',
    confirmText:'تأیید', danger:false
  });
  if(!ok) return;
  try{
    await apiPatch('/users/'+id+'/role', { role:next });
    toast('نقش کاربر تغییر کرد.','ok');
    if(state.refresh) state.refresh();
  }catch(e){ toast('خطا: '+e.message,'err'); }
}
async function toggleUser(id){
  try{
    await apiPatch('/users/'+id+'/toggle');
    toast('وضعیت کاربر تغییر کرد.','ok');
    if(state.refresh) state.refresh();
  }catch(e){ toast('خطا: '+e.message,'err'); }
}
async function deleteUser(id){
  const ok = await confirmDialog({ title:'حذف کاربر', message:'این کاربر حذف خواهد شد. مطمئنید؟' });
  if(!ok) return;
  try{
    await apiDel('/users/'+id);
    toast('کاربر حذف شد.','ok');
    if(state.refresh) state.refresh();
  }catch(e){ toast('خطا: '+e.message,'err'); }
}

/* ================================================================
   PAGE: Reviews
   ================================================================ */
async function renderReviews(root){
  root.innerHTML = `
    <div class="adm-sec-head"><h2>نظرات</h2></div>
    <div class="adm-card"><div class="adm-tbl-wrap"><table class="adm-tbl">
      <thead><tr><th>کاربر</th><th>محصول</th><th>امتیاز</th><th>متن</th><th>وضعیت</th><th class="col-actions">عملیات</th></tr></thead>
      <tbody id="revTbody"></tbody>
    </table></div></div>
  `;

  const tbody = $('#revTbody');
  const load = async ()=>{
    tbody.innerHTML = '<tr><td colspan="6"><div class="adm-sk adm-sk-row"></div></td></tr>';
    try{
      const res = await apiGet('/reviews');
      const list = res.reviews || [];
      if(!list.length){
        tbody.innerHTML = '<tr><td colspan="6"><div class="adm-empty"><h3>نظری وجود ندارد</h3></div></td></tr>';
        return;
      }
      tbody.innerHTML = list.map(r=>`
        <tr>
          <td><b>${esc(r.user?.name||'-')}</b><div class="adm-stat-lbl" dir="ltr">${esc(r.user?.email||'')}</div></td>
          <td>${esc(r.product?.name||'-')}</td>
          <td>${fa(r.rating)} ★</td>
          <td style="max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(r.comment)}</td>
          <td>${r.isApproved?'<span class="adm-bdg ok">تأیید</span>':'<span class="adm-bdg warn">در انتظار</span>'}</td>
          <td class="col-actions"><div class="adm-tbl-actions">
            <button class="adm-iconbtn-sm" data-approve="${r._id}" title="تأیید/لغو">${ic('check',16)}</button>
            <button class="adm-iconbtn-sm danger" data-del="${r._id}" title="حذف">${ic('trash',16)}</button>
          </div></td>
        </tr>
      `).join('');
      tbody.querySelectorAll('[data-approve]').forEach(b=>b.onclick=()=>toggleRev(b.dataset.approve));
      tbody.querySelectorAll('[data-del]').forEach(b=>b.onclick=()=>deleteRev(b.dataset.del));
    }catch(e){ toast('خطا: '+e.message,'err'); }
  };

  async function toggleRev(id){
    try{ await apiPatch('/reviews/'+id+'/approve'); toast('وضعیت نظر تغییر کرد.','ok'); if(state.refresh) state.refresh(); }
    catch(e){ toast('خطا: '+e.message,'err'); }
  }
  async function deleteRev(id){
    const ok = await confirmDialog({ title:'حذف نظر', message:'این نظر حذف می‌شود.' });
    if(!ok) return;
    try{ await apiDel('/reviews/'+id); toast('نظر حذف شد.','ok'); if(state.refresh) state.refresh(); }
    catch(e){ toast('خطا: '+e.message,'err'); }
  }

  state.refresh = load;
  load();
}

/* ================================================================
   PAGE: Account
   ================================================================ */
async function renderAccount(root){
  const u = currentUser || {};
  root.innerHTML = `
    <div class="adm-sec-head"><h2>حساب من</h2></div>
    <div class="adm-card adm-card-pad" style="max-width:560px">
      <div style="display:flex;align-items:center;gap:14px;margin-bottom:20px">
        <div class="adm-avatar" style="width:56px;height:56px;font-size:22px">${esc((u.name||'م')[0])}</div>
        <div><div style="font-weight:800;font-size:16px">${esc(u.name||'-')}</div><div class="adm-stat-lbl" dir="ltr">${esc(u.email||'-')}</div></div>
      </div>
      <div class="adm-fld"><label>شماره موبایل</label><div dir="ltr">${esc(u.phone||'-')}</div></div>
      <div class="adm-fld"><label>نقش</label><div>${u.role==='admin'?'<span class="adm-bdg brand">ادمین</span>':'<span class="adm-bdg">کاربر</span>'}</div></div>
    </div>

    <div class="adm-card adm-card-pad" style="max-width:560px">
      <h3 style="margin:0 0 14px;font-size:15px">تغییر رمز عبور</h3>
      <form id="pwdForm">
        <div class="adm-fld"><label>رمز فعلی</label><input class="adm-input" type="password" name="current" dir="ltr"></div>
        <div class="adm-fld"><label>رمز جدید (حداقل ۶ کاراکتر)</label><input class="adm-input" type="password" name="next" dir="ltr"></div>
        <button class="adm-btn primary" type="submit" id="pwdBtn">${ic('check',18)} تغییر رمز</button>
      </form>
    </div>
  `;

  $('#pwdForm').onsubmit = async e=>{
    e.preventDefault();
    const f = e.target;
    const cur = f.elements.current.value;
    const nxt = f.elements.next.value;
    if(!cur || nxt.length<6){ toast('رمز جدید حداقل ۶ کاراکتر باشد.','warn'); return; }
    const btn = $('#pwdBtn');
    btn.disabled = true;
    try{
      await apiPut('/auth/change-password',{ currentPassword:cur, newPassword:nxt });
      toast('رمز عبور تغییر کرد.','ok');
      f.reset();
    }catch(err){ toast('خطا: '+err.message,'err'); }
    finally{ btn.disabled = false; }
  };
}


/* ================================================================
   PAGE: CMS Pages
   ================================================================ */
async function renderCmsPages(root){
  root.innerHTML = `
    <div class="adm-sec-head">
      <h2>صفحات سایت</h2>
      <span class="adm-sec-sub" id="cmsPageCount">—</span>
      <div class="adm-sec-actions">
        <button class="adm-btn primary" id="cmsNewPage" type="button">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>
          صفحه جدید
        </button>
      </div>
    </div>
    <div class="adm-card">
      <div class="adm-tbl-wrap">
        <table class="adm-tbl">
          <thead><tr><th>عنوان</th><th>آدرس</th><th>انتشار</th><th>منو</th><th>ترتیب</th><th class="col-actions">عملیات</th></tr></thead>
          <tbody id="cmsPageBody"></tbody>
        </table>
      </div>
    </div>
  `;

  const body = root.querySelector('#cmsPageBody');

  async function load(){
    body.innerHTML = '<tr><td colspan="6"><div class="adm-sk adm-sk-row"></div></td></tr>';
    try{
      const res = await apiGet('/cms/pages?all=true');
      const list = res.pages || [];
      root.querySelector('#cmsPageCount').textContent = fa(list.length) + ' صفحه';
      if(!list.length){
        body.innerHTML = '<tr><td colspan="6"><div class="adm-empty" style="padding:48px 16px"><h3>صفحه‌ای ثبت نشده</h3></div></td></tr>';
        return;
      }
      body.innerHTML = list.map(function(p){
        var pub = p.is_published ? '<span class="adm-bdg ok">منتشرشده</span>' : '<span class="adm-bdg">پیش‌نویس</span>';
        var menu = p.show_in_menu ? '<span class="adm-bdg info">بله</span>' : '<span class="adm-bdg">خیر</span>';
        return '<tr>'
          + '<td><b>' + esc(p.title) + '</b></td>'
          + '<td><code dir="ltr" class="adm-sku">' + esc(p.slug) + '</code></td>'
          + '<td>' + pub + '</td>'
          + '<td>' + menu + '</td>'
          + '<td>' + fa(p.sort_order || 0) + '</td>'
          + '<td class="col-actions"><div class="adm-tbl-actions">'
          + '<button class="adm-iconbtn-sm" data-edit="' + p.id + '"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.1 2.1 0 1 1 3 3L12 15l-4 1 1-4z"/></svg></button>'
          + '<button class="adm-iconbtn-sm danger" data-del="' + p.id + '"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg></button>'
          + '</div></td></tr>';
      }).join('');
      body.querySelectorAll('[data-edit]').forEach(function(b){ b.onclick = function(){ openPageForm(list.find(function(x){ return x.id === +b.dataset.edit; })); }; });
      body.querySelectorAll('[data-del]').forEach(function(b){ b.onclick = function(){ deletePage(+b.dataset.del); }; });
    }catch(e){
      body.innerHTML = '<tr><td colspan="6" style="padding:32px;text-align:center;color:var(--adm-danger)">' + esc(e.message) + '</td></tr>';
    }
  }

  async function deletePage(id){
    var ok = await confirmDialog({ title:'حذف صفحه', message:'مطمئنید؟', confirmText:'حذف' });
    if(!ok) return;
    try{ await apiDel('/cms/pages/' + id); toast('حذف شد.', 'ok'); load(); }catch(e){ toast('خطا: ' + e.message, 'err'); }
  }

  function openPageForm(p){
    var isEdit = !!p;
    openModal(
      '<div class="adm-modal-head"><h3>' + (isEdit ? 'ویرایش' : 'صفحه جدید') + '</h3><button class="adm-iconbtn-sm" data-close type="button" style="margin-inline-start:auto"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>'
      + '<div class="adm-modal-body">'
      + '<div class="adm-grid-2"><div class="adm-fld"><label>عنوان <span class="req">*</span></label><input class="adm-input" id="cpTitle" value="' + esc(p ? p.title : '') + '" data-autofocus></div>'
      + '<div class="adm-fld"><label>slug</label><input class="adm-input" id="cpSlug" dir="ltr" value="' + esc(p ? p.slug : '') + '"></div></div>'
      + '<div class="adm-fld"><label>محتوا (HTML)</label><textarea class="adm-textarea" id="cpContent" rows="10" dir="ltr">' + esc(p ? p.content : '') + '</textarea></div>'
      + '<div class="adm-grid-2"><div class="adm-fld"><label>Meta Title</label><input class="adm-input" id="cpMetaTitle" value="' + esc(p ? p.meta_title || '' : '') + '"></div>'
      + '<div class="adm-fld"><label>ترتیب</label><input class="adm-input" id="cpSort" inputmode="numeric" value="' + ((p && p.sort_order) || 0) + '"></div></div>'
      + '<div class="adm-fld"><label>Meta Description</label><textarea class="adm-textarea" id="cpMetaDesc" rows="2">' + esc(p ? p.meta_description || '' : '') + '</textarea></div>'
      + '<div class="adm-fld"><label style="display:flex;gap:8px"><input type="checkbox" id="cpPub" ' + ((!p || p.is_published) ? 'checked' : '') + '> منتشر شود</label></div>'
      + '<div class="adm-fld"><label style="display:flex;gap:8px"><input type="checkbox" id="cpMenu" ' + ((p && p.show_in_menu) ? 'checked' : '') + '> نمایش در منو</label></div>'
      + '</div>'
      + '<div class="adm-modal-foot"><button class="adm-btn outline" data-close type="button">انصراف</button><button class="adm-btn primary" id="cpSave" type="button">' + (isEdit ? 'ذخیره' : 'افزودن') + '</button></div>'
    );
    document.querySelector('#cpSave').onclick = async function(){
      var payload = {
        title: document.querySelector('#cpTitle').value.trim(),
        slug: document.querySelector('#cpSlug').value.trim(),
        content: document.querySelector('#cpContent').value,
        meta_title: document.querySelector('#cpMetaTitle').value.trim(),
        meta_description: document.querySelector('#cpMetaDesc').value.trim(),
        sort_order: Number(document.querySelector('#cpSort').value) || 0,
        is_published: document.querySelector('#cpPub').checked,
        show_in_menu: document.querySelector('#cpMenu').checked
      };
      if(payload.title.length < 2){ toast('عنوان الزامی است.', 'warn'); return; }
      if(!payload.slug) payload.slug = payload.title.toLowerCase().replace(/\s+/g,'-').replace(/[^\w\u0600-\u06FF-]/g,'');
      try{
        if(isEdit) await apiPut('/cms/pages/' + p.id, payload);
        else       await apiPost('/cms/pages', payload);
        toast(isEdit ? 'ویرایش شد.' : 'افزوده شد.', 'ok');
        closeModal(); load();
      }catch(e){ toast('خطا: ' + e.message, 'err'); }
    };
  }

  root.querySelector('#cmsNewPage').onclick = function(){ openPageForm(null); };
  load();
}

/* ================================================================
   PAGE: CMS Banners
   ================================================================ */
async function renderCmsBanners(root){
  root.innerHTML = `
    <div class="adm-sec-head">
      <h2>بنرها</h2>
      <span class="adm-sec-sub" id="cmsBanCount">—</span>
      <div class="adm-sec-actions"><button class="adm-btn primary" id="cmsNewBan" type="button"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg> بنر جدید</button></div>
    </div>
    <div class="adm-cms-grid" id="cmsBanGrid"></div>
  `;

  const grid = root.querySelector('#cmsBanGrid');

  async function load(){
    grid.innerHTML = '<div class="adm-sk" style="height:220px;border-radius:14px"></div>'.repeat(3);
    try{
      const res = await apiGet('/cms/banners?all=true');
      const list = res.banners || [];
      root.querySelector('#cmsBanCount').textContent = fa(list.length) + ' بنر';
      if(!list.length){
        grid.innerHTML = '<div class="adm-empty" style="grid-column:1/-1;padding:56px 16px"><h3>بنری ثبت نشده</h3></div>';
        return;
      }
      grid.innerHTML = list.map(function(b){
        var active = b.is_active ? '<span class="adm-bdg ok">فعال</span>' : '<span class="adm-bdg">غیرفعال</span>';
        var img = window.__ASSET__ ? window.__ASSET__(b.image_url) : b.image_url;
        return '<div class="adm-cms-card">'
          + '<div class="adm-cms-img" style="background-image:url(' + JSON.stringify(img) + ')"><div class="adm-cms-img-overlay">' + active + '</div></div>'
          + '<div class="adm-cms-info"><b>' + esc(b.title || '(بدون عنوان)') + '</b><div class="adm-cms-meta"><span>' + esc(b.position || 'top') + '</span><span>ترتیب: ' + fa(b.sort_order || 0) + '</span></div></div>'
          + '<div class="adm-cms-actions">'
          + '<button class="adm-iconbtn-sm" data-edit="' + b.id + '"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.1 2.1 0 1 1 3 3L12 15l-4 1 1-4z"/></svg></button>'
          + '<button class="adm-iconbtn-sm" data-toggle="' + b.id + '">' + (b.is_active ? '<svg width="16" height="16" viewBox="0 0 24 24"><rect x="2" y="6" width="20" height="12" rx="6" fill="currentColor"/><circle cx="17" cy="12" r="4" fill="#fff"/></svg>' : '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="6" width="20" height="12" rx="6"/><circle cx="7" cy="12" r="3" fill="currentColor"/></svg>') + '</button>'
          + '<button class="adm-iconbtn-sm danger" data-del="' + b.id + '"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg></button>'
          + '</div></div>';
      }).join('');
      grid.querySelectorAll('[data-edit]').forEach(function(el){ el.onclick = function(){ openBannerForm(list.find(function(x){ return x.id === +el.dataset.edit; })); }; });
      grid.querySelectorAll('[data-toggle]').forEach(function(el){
        el.onclick = function(){
          var item = list.find(function(x){ return x.id === +el.dataset.toggle; });
          apiPut('/cms/banners/' + item.id, { is_active: !item.is_active }).then(load).catch(function(e){ toast('خطا: ' + e.message, 'err'); });
        };
      });
      grid.querySelectorAll('[data-del]').forEach(function(el){
        el.onclick = async function(){
          var ok = await confirmDialog({ title:'حذف', message:'مطمئنید؟', confirmText:'حذف' });
          if(!ok) return;
          try{ await apiDel('/cms/banners/' + el.dataset.del); toast('حذف شد.', 'ok'); load(); }catch(e){ toast('خطا: ' + e.message, 'err'); }
        };
      });
    }catch(e){
      grid.innerHTML = '<div style="grid-column:1/-1;padding:32px;text-align:center;color:var(--adm-danger)">' + esc(e.message) + '</div>';
    }
  }

  function openBannerForm(b){
    var isEdit = !!b;
    var currentUrl = b ? b.image_url : '';
    openModal(
      '<div class="adm-modal-head"><h3>' + (isEdit ? 'ویرایش بنر' : 'بنر جدید') + '</h3><button class="adm-iconbtn-sm" data-close type="button" style="margin-inline-start:auto"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>'
      + '<div class="adm-modal-body">'
      + '<div class="adm-fld"><label>عنوان</label><input class="adm-input" id="cbTitle" value="' + esc(b ? b.title || '' : '') + '"></div>'
      + '<div class="adm-fld"><label>تصویر <span class="req">*</span></label>'
      + '<div class="adm-cms-img-picker" id="cbImgPicker" style="background-image:url(' + JSON.stringify(currentUrl ? (window.__ASSET__ ? window.__ASSET__(currentUrl) : currentUrl) : '') + ')"><div class="adm-cms-img-picker-empty">برای انتخاب کلیک کنید</div></div>'
      + '<input type="hidden" id="cbImg" value="' + esc(currentUrl) + '">'
      + '<label class="adm-btn outline sm" for="cbFile" style="margin-top:8px;display:inline-flex;cursor:pointer">آپلود از دستگاه</label>'
      + '<input type="file" id="cbFile" accept="image/*" style="display:none" onchange="window.__cmsBannerPick && window.__cmsBannerPick(this)">'
      + '</div>'
      + '<div class="adm-fld"><label>لینک (اختیاری)</label><input class="adm-input" id="cbLink" dir="ltr" value="' + esc(b ? b.link || '' : '') + '"></div>'
      + '<div class="adm-grid-2"><div class="adm-fld"><label>موقعیت</label><select class="adm-select" id="cbPos">'
      + ['top','middle','sidebar','footer'].map(function(v){ return '<option value="' + v + '" ' + ((b && b.position === v) || (!b && v === 'top') ? 'selected' : '') + '>' + v + '</option>'; }).join('')
      + '</select></div>'
      + '<div class="adm-fld"><label>ترتیب</label><input class="adm-input" id="cbSort" inputmode="numeric" value="' + ((b && b.sort_order) || 0) + '"></div></div>'
      + '<div class="adm-fld"><label style="display:flex;gap:8px"><input type="checkbox" id="cbActive" ' + ((!b || b.is_active) ? 'checked' : '') + '> فعال</label></div>'
      + '</div>'
      + '<div class="adm-modal-foot"><button class="adm-btn outline" data-close type="button">انصراف</button><button class="adm-btn primary" id="cbSave" type="button">' + (isEdit ? 'ذخیره' : 'افزودن') + '</button></div>'
    );
    var picker = document.querySelector('#cbImgPicker');
    if(picker) picker.onclick = function(){ document.querySelector('#cbFile').click(); };
    window.__cmsBannerPick = function(input){
      var f = input.files && input.files[0];
      input.value = '';
      if(!f) return;
      if(f.size > 5 * 1024 * 1024){ toast('حجم بیش از ۵ مگابایت.', 'warn'); return; }
      picker.innerHTML = '<div class="adm-cms-img-picker-loading">در حال آپلود...</div>';
      var API = window.__API_BASE || (typeof API !== 'undefined' ? API : '');
      var fd = new FormData();
      fd.append('image', f);
      var xhr = new XMLHttpRequest();
      xhr.open('POST', API + '/upload/product-single', true);
      xhr.withCredentials = true;
      xhr.onload = function(){
        try{
          var r = JSON.parse(xhr.responseText || '{}');
          if(xhr.status >= 200 && xhr.status < 300 && r.success){
            document.querySelector('#cbImg').value = r.url;
            picker.style.backgroundImage = 'url(' + JSON.stringify(window.__ASSET__ ? window.__ASSET__(r.url) : r.url) + ')';
            picker.innerHTML = '<div class="adm-cms-img-picker-empty"></div>';
            toast('آپلود شد.', 'ok');
          }else{
            picker.innerHTML = '<div class="adm-cms-img-picker-empty">کلیک کنید</div>';
            toast('خطا: ' + (r.message || '?'), 'err');
          }
        }catch(e){ picker.innerHTML = '<div class="adm-cms-img-picker-empty">کلیک کنید</div>'; toast('خطای پاسخ', 'err'); }
      };
      xhr.onerror = function(){ picker.innerHTML = '<div class="adm-cms-img-picker-empty">کلیک کنید</div>'; toast('خطای شبکه', 'err'); };
      xhr.send(fd);
    };
    document.querySelector('#cbSave').onclick = async function(){
      var payload = {
        title: document.querySelector('#cbTitle').value.trim(),
        image_url: document.querySelector('#cbImg').value,
        link: document.querySelector('#cbLink').value.trim(),
        position: document.querySelector('#cbPos').value,
        sort_order: Number(document.querySelector('#cbSort').value) || 0,
        is_active: document.querySelector('#cbActive').checked
      };
      if(!payload.image_url){ toast('تصویر الزامی است.', 'warn'); return; }
      try{
        if(isEdit) await apiPut('/cms/banners/' + b.id, payload);
        else       await apiPost('/cms/banners', payload);
        toast(isEdit ? 'ویرایش شد.' : 'افزوده شد.', 'ok');
        closeModal(); load();
      }catch(e){ toast('خطا: ' + e.message, 'err'); }
    };
  }

  root.querySelector('#cmsNewBan').onclick = function(){ openBannerForm(null); };
  load();
}

/* ================================================================
   PAGE: CMS Sliders
   ================================================================ */
async function renderCmsSliders(root){
  root.innerHTML = `
    <div class="adm-sec-head">
      <h2>اسلایدر</h2>
      <span class="adm-sec-sub" id="cmsSlCount">—</span>
      <div class="adm-sec-actions"><button class="adm-btn primary" id="cmsNewSl" type="button"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg> اسلاید جدید</button></div>
    </div>
    <div class="adm-cms-grid" id="cmsSlGrid"></div>
  `;

  const grid = root.querySelector('#cmsSlGrid');

  async function load(){
    grid.innerHTML = '<div class="adm-sk" style="height:220px;border-radius:14px"></div>'.repeat(3);
    try{
      const res = await apiGet('/cms/sliders?all=true');
      const list = res.sliders || [];
      root.querySelector('#cmsSlCount').textContent = fa(list.length) + ' اسلاید';
      if(!list.length){
        grid.innerHTML = '<div class="adm-empty" style="grid-column:1/-1;padding:56px 16px"><h3>اسلایدی ثبت نشده</h3></div>';
        return;
      }
      grid.innerHTML = list.map(function(s){
        var active = s.is_active ? '<span class="adm-bdg ok">فعال</span>' : '<span class="adm-bdg">غیرفعال</span>';
        var img = window.__ASSET__ ? window.__ASSET__(s.image_url) : s.image_url;
        return '<div class="adm-cms-card">'
          + '<div class="adm-cms-img" style="background-image:url(' + JSON.stringify(img) + ')"><div class="adm-cms-img-overlay">' + active + '</div></div>'
          + '<div class="adm-cms-info"><b>' + esc(s.title || '(بدون عنوان)') + '</b><div class="adm-cms-meta"><span>' + esc(s.subtitle || '') + '</span><span>ترتیب: ' + fa(s.sort_order || 0) + '</span></div></div>'
          + '<div class="adm-cms-actions">'
          + '<button class="adm-iconbtn-sm" data-edit="' + s.id + '"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.1 2.1 0 1 1 3 3L12 15l-4 1 1-4z"/></svg></button>'
          + '<button class="adm-iconbtn-sm" data-toggle="' + s.id + '">' + (s.is_active ? '<svg width="16" height="16" viewBox="0 0 24 24"><rect x="2" y="6" width="20" height="12" rx="6" fill="currentColor"/><circle cx="17" cy="12" r="4" fill="#fff"/></svg>' : '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="6" width="20" height="12" rx="6"/><circle cx="7" cy="12" r="3" fill="currentColor"/></svg>') + '</button>'
          + '<button class="adm-iconbtn-sm danger" data-del="' + s.id + '"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg></button>'
          + '</div></div>';
      }).join('');
      grid.querySelectorAll('[data-edit]').forEach(function(el){ el.onclick = function(){ openSliderForm(list.find(function(x){ return x.id === +el.dataset.edit; })); }; });
      grid.querySelectorAll('[data-toggle]').forEach(function(el){
        el.onclick = function(){
          var item = list.find(function(x){ return x.id === +el.dataset.toggle; });
          apiPut('/cms/sliders/' + item.id, { is_active: !item.is_active }).then(load).catch(function(e){ toast('خطا: ' + e.message, 'err'); });
        };
      });
      grid.querySelectorAll('[data-del]').forEach(function(el){
        el.onclick = async function(){
          var ok = await confirmDialog({ title:'حذف', message:'مطمئنید؟', confirmText:'حذف' });
          if(!ok) return;
          try{ await apiDel('/cms/sliders/' + el.dataset.del); toast('حذف شد.', 'ok'); load(); }catch(e){ toast('خطا: ' + e.message, 'err'); }
        };
      });
    }catch(e){
      grid.innerHTML = '<div style="grid-column:1/-1;padding:32px;text-align:center;color:var(--adm-danger)">' + esc(e.message) + '</div>';
    }
  }

  function openSliderForm(s){
    var isEdit = !!s;
    var currentUrl = s ? s.image_url : '';
    openModal(
      '<div class="adm-modal-head"><h3>' + (isEdit ? 'ویرایش اسلاید' : 'اسلاید جدید') + '</h3><button class="adm-iconbtn-sm" data-close type="button" style="margin-inline-start:auto"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>'
      + '<div class="adm-modal-body">'
      + '<div class="adm-grid-2"><div class="adm-fld"><label>عنوان</label><input class="adm-input" id="csTitle" value="' + esc(s ? s.title || '' : '') + '"></div>'
      + '<div class="adm-fld"><label>زیرعنوان</label><input class="adm-input" id="csSubtitle" value="' + esc(s ? s.subtitle || '' : '') + '"></div></div>'
      + '<div class="adm-fld"><label>تصویر <span class="req">*</span></label>'
      + '<div class="adm-cms-img-picker" id="csImgPicker" style="background-image:url(' + JSON.stringify(currentUrl ? (window.__ASSET__ ? window.__ASSET__(currentUrl) : currentUrl) : '') + ')"><div class="adm-cms-img-picker-empty">برای انتخاب کلیک کنید</div></div>'
      + '<input type="hidden" id="csImg" value="' + esc(currentUrl) + '">'
      + '<label class="adm-btn outline sm" for="csFile" style="margin-top:8px;display:inline-flex;cursor:pointer">آپلود از دستگاه</label>'
      + '<input type="file" id="csFile" accept="image/*" style="display:none" onchange="window.__cmsSliderPick && window.__cmsSliderPick(this)">'
      + '</div>'
      + '<div class="adm-grid-2"><div class="adm-fld"><label>لینک</label><input class="adm-input" id="csLink" dir="ltr" value="' + esc(s ? s.link || '' : '') + '"></div>'
      + '<div class="adm-fld"><label>متن دکمه</label><input class="adm-input" id="csBtn" value="' + esc(s ? s.button_text || 'مشاهده' : 'مشاهده') + '"></div></div>'
      + '<div class="adm-grid-2"><div class="adm-fld"><label>رنگ پس‌زمینه</label><input class="adm-input" id="csBg" dir="ltr" value="' + esc(s ? s.bg_color || '#0f172a' : '#0f172a') + '"></div>'
      + '<div class="adm-fld"><label>ترتیب</label><input class="adm-input" id="csSort" inputmode="numeric" value="' + ((s && s.sort_order) || 0) + '"></div></div>'
      + '<div class="adm-fld"><label style="display:flex;gap:8px"><input type="checkbox" id="csActive" ' + ((!s || s.is_active) ? 'checked' : '') + '> فعال</label></div>'
      + '</div>'
      + '<div class="adm-modal-foot"><button class="adm-btn outline" data-close type="button">انصراف</button><button class="adm-btn primary" id="csSave" type="button">' + (isEdit ? 'ذخیره' : 'افزودن') + '</button></div>'
    );
    var picker = document.querySelector('#csImgPicker');
    if(picker) picker.onclick = function(){ document.querySelector('#csFile').click(); };
    window.__cmsSliderPick = function(input){
      var f = input.files && input.files[0];
      input.value = '';
      if(!f) return;
      if(f.size > 5 * 1024 * 1024){ toast('حجم بیش از ۵ مگابایت.', 'warn'); return; }
      picker.innerHTML = '<div class="adm-cms-img-picker-loading">در حال آپلود...</div>';
      var API = window.__API_BASE || (typeof API !== 'undefined' ? API : '');
      var fd = new FormData();
      fd.append('image', f);
      var xhr = new XMLHttpRequest();
      xhr.open('POST', API + '/upload/product-single', true);
      xhr.withCredentials = true;
      xhr.onload = function(){
        try{
          var r = JSON.parse(xhr.responseText || '{}');
          if(xhr.status >= 200 && xhr.status < 300 && r.success){
            document.querySelector('#csImg').value = r.url;
            picker.style.backgroundImage = 'url(' + JSON.stringify(window.__ASSET__ ? window.__ASSET__(r.url) : r.url) + ')';
            picker.innerHTML = '<div class="adm-cms-img-picker-empty"></div>';
            toast('آپلود شد.', 'ok');
          }else{
            picker.innerHTML = '<div class="adm-cms-img-picker-empty">کلیک کنید</div>';
            toast('خطا: ' + (r.message || '?'), 'err');
          }
        }catch(e){ picker.innerHTML = '<div class="adm-cms-img-picker-empty">کلیک کنید</div>'; toast('خطای پاسخ', 'err'); }
      };
      xhr.onerror = function(){ picker.innerHTML = '<div class="adm-cms-img-picker-empty">کلیک کنید</div>'; toast('خطای شبکه', 'err'); };
      xhr.send(fd);
    };
    document.querySelector('#csSave').onclick = async function(){
      var payload = {
        title: document.querySelector('#csTitle').value.trim(),
        subtitle: document.querySelector('#csSubtitle').value.trim(),
        image_url: document.querySelector('#csImg').value,
        link: document.querySelector('#csLink').value.trim(),
        button_text: document.querySelector('#csBtn').value.trim(),
        bg_color: document.querySelector('#csBg').value.trim(),
        sort_order: Number(document.querySelector('#csSort').value) || 0,
        is_active: document.querySelector('#csActive').checked
      };
      if(!payload.image_url){ toast('تصویر الزامی است.', 'warn'); return; }
      try{
        if(isEdit) await apiPut('/cms/sliders/' + s.id, payload);
        else       await apiPost('/cms/sliders', payload);
        toast(isEdit ? 'ویرایش شد.' : 'افزوده شد.', 'ok');
        closeModal(); load();
      }catch(e){ toast('خطا: ' + e.message, 'err'); }
    };
  }

  root.querySelector('#cmsNewSl').onclick = function(){ openSliderForm(null); };
  load();
}

/* ================================================================
   INIT
   ================================================================ */
async function init(){
  hydrateIcons();
  renderNav();

  /* چک امنیتی: کاربر باید ادمین باشد */
  try{
    const r = await apiGet('/auth/me');
    if(!r.user || r.user.role !== 'admin'){
      showBoot('دسترسی ادمین لازم است. در حال انتقال...');
      setTimeout(()=>{ location.href='index.html'; }, 1200);
      return;
    }
    currentUser = r.user;
    const initials = (r.user.name||'م').trim().charAt(0);
    $('#userAvatar').textContent = initials;
    $('#userName').textContent = r.user.name || 'کاربر';
    $('#userEmail').textContent = r.user.email || '';
  }catch(err){
    if(err.message !== 'unauthenticated'){
      showBoot('خطا در احراز هویت. لطفاً وارد شوید.');
      setTimeout(()=>{ location.href='index.html'; }, 1400);
    }
    return;
  }

  /* نمایش پنل */
  $('#bootLoader').hidden = true;
  $('#app').hidden = false;

  go('dashboard');
}

init();

  /* __FORCE_TOABS__ */
  window.__toAbsUrl = function(u){
    if(!u) return '';
    if(/^https?:\/\//.test(u)) return u;
    var origin = window.__BACKEND_ORIGIN__ || '';
    if(!origin){
      var api = window.__API_BASE || '';
      origin = api.replace(/\/api$/, '');
    }
    if(u.charAt(0) === '/') return origin + u;
    return origin + '/' + u;
  };
  /* override the local toAbsUrl if it exists in this scope */
  if(typeof toAbsUrl === 'function'){
    try{ toAbsUrl = window.__toAbsUrl; }catch(e){}
  }

})();