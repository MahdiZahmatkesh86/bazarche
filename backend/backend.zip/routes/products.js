const express = require('express');
const router = express.Router();

/* __cache_buster__ */
const { del: _cDel } = require('../utils/cache');
router.use(function(req, res, next){
  if(req.method === 'GET') return next();
  res.on('finish', function(){
    if(res.statusCode >= 200 && res.statusCode < 300){
      try{ _cDel('http:/api/products'); }catch(e){}
    }
  });
  next();
});

const { body } = require('express-validator');
const validate = require('../middleware/validate');
const { protect, adminOnly } = require('../middleware/auth');
const ctrl = require('../controllers/productController');

router.get('/', ctrl.list);
router.get('/:id', ctrl.getOne);

router.get('/admin/stats', protect, adminOnly, ctrl.stats);
router.post('/:id/duplicate',     protect, adminOnly, ctrl.duplicate);
router.get('/admin/generate-sku', protect, adminOnly, ctrl.generateSku);

const rules = [
  body('name').trim().isLength({ min:2 }).withMessage('نام محصول الزامی است.'),
  body('brand').trim().notEmpty().withMessage('برند الزامی است.'),
  body('category').notEmpty().withMessage('دسته‌بندی الزامی است.'),
  body('price').isNumeric().withMessage('قیمت باید عدد باشد.'),
  body('stock').isNumeric().withMessage('موجودی باید عدد باشد.')
];

router.post('/',    protect, adminOnly, rules, validate, ctrl.create);
router.put('/:id',  protect, adminOnly, ctrl.update);
router.delete('/:id', protect, adminOnly, ctrl.remove);
router.patch('/:id/toggle', protect, adminOnly, ctrl.toggleActive);

module.exports = router;