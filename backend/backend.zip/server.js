require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const morgan = require('morgan');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs');

const { initSchema } = require('./db/init');
const errorHandler = require('./middleware/error');
const { cacheMiddleware } = require('./utils/cache');

const app = express();
app.set('trust proxy', 1);

app.use(helmet({ crossOriginResourcePolicy:false }));
app.use(cors({
  origin: function(origin, callback){ callback(null, true); },
  credentials: true
}));
app.use(express.json({ limit:'10mb' }));
app.use(express.urlencoded({ extended:true }));
app.use(cookieParser());

if(process.env.NODE_ENV === 'development') app.use(morgan('dev'));
/* Serve uploaded files */
app.use('/uploads', express.static(path.join(__dirname, 'uploads'), {
  maxAge: '7d',
  setHeaders: (res) => { res.setHeader('Access-Control-Allow-Origin', '*'); }
}));

const limiter = rateLimit({
  windowMs:15*60*1000, max:300,
  message:{ success:false, message:'تعداد درخواست‌ها زیاد است.' }
});
app.use('/api', limiter);

const authLimiter = rateLimit({
  windowMs:15*60*1000, max:20,
  message:{ success:false, message:'تعداد تلاش‌های ورود زیاد است.' }
});

app.get('/', (req,res)=>res.json({ success:true, message:'Bazaarche API', version:'3.0.0' }));
app.get('/api/health', (req,res)=>res.json({ success:true, uptime:process.uptime() }));

app.use('/api/auth', require('./routes/auth'));
app.use('/api/products',   cacheMiddleware(30000), require('./routes/products'));
app.use('/api/upload',      require('./routes/upload'));
app.use('/api/categories', cacheMiddleware(60000), require('./routes/categories'));
app.use('/api/users',      require('./routes/users'));
app.use('/api/orders',     require('./routes/orders'));
app.use('/api/reviews',    require('./routes/reviews'));
app.use('/api/site',       require('./routes/site'));
app.use('/api/cms',        cacheMiddleware(60000), require('./routes/cms'));

const pub = path.join(__dirname, 'public');
if(fs.existsSync(pub)){
  app.use(express.static(pub));
  app.get(/^\/(?!api).*/, (req,res)=>res.sendFile(path.join(pub, 'index.html')));
}

app.use((req,res)=>res.status(404).json({ success:false, message:'مسیر پیدا نشد.' }));
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

(async () => {
  try{
    await initSchema();
    app.listen(PORT, ()=>console.log('[Server] Running on port ' + PORT + ' (' + process.env.NODE_ENV + ')'));
  }catch(err){
    console.error('[FATAL] DB init failed:', err.message);
    process.exit(1);
  }
})();