/* ================================================================
   config.js — تنظیمات مرکزی پروژه
   ================================================================
   این فایل باید *قبل از* همه اسکریپت‌های دیگر بارگذاری شود.
   ================================================================ */
(function(){
  'use strict';

  var DEV_BACKEND_PORT = 5000;
  var DEV_PORTS = [3000, 4200, 5173, 5500, 5501, 8000, 8080];

  var loc = window.location;
  var isFile = loc.protocol === 'file:';
  var isLocalhost = loc.hostname === 'localhost'
                 || loc.hostname === '127.0.0.1'
                 || loc.hostname === '0.0.0.0'
                 || loc.hostname === '::1';
  var port = parseInt(loc.port, 10) || 0;
  var isDevPort = DEV_PORTS.indexOf(port) !== -1;

  var BACKEND_ORIGIN, MODE;

  if (isFile) {
    BACKEND_ORIGIN = 'http://127.0.0.1:' + DEV_BACKEND_PORT;
    MODE = 'file';
  } else if (isLocalhost && isDevPort) {
    BACKEND_ORIGIN = loc.protocol + '//' + loc.hostname + ':' + DEV_BACKEND_PORT;
    MODE = 'local-dev';
  } else {
    BACKEND_ORIGIN = loc.origin;
    MODE = 'production';
  }

  var API_BASE = BACKEND_ORIGIN + '/api';

  window.__API_BASE__       = API_BASE;
  window.__API_BASE         = API_BASE;
  window.__BACKEND_ORIGIN__ = BACKEND_ORIGIN;
  window.__BACKEND__        = BACKEND_ORIGIN;
  window.__API_ORIGIN__     = BACKEND_ORIGIN;
  window.__CONFIG_MODE__    = MODE;

  /* ثابت‌های ارسال — از سرور هم بیاد بهتر، ولی اینجا هاردکد برای هماهنگی */
  window.__SHIPPING__ = {
    FREE_THRESHOLD: 10000000,
    COST: 600000
  };

  window.__ASSET__ = function(u){
    if (!u) return '';
    u = String(u);
    if (/^https?:\/\//i.test(u)) return u;
    if (/^data:/i.test(u))         return u;
    if (/^blob:/i.test(u))         return u;
    if (u.charAt(0) === '/')       return BACKEND_ORIGIN + u;
    return BACKEND_ORIGIN + '/' + u;
  };

  window.__resolveCardImg = function(p){
    if (!p) return null;
    var imgs = p.imgs || p.images || p.image || null;
    var u = null;
    if (Array.isArray(imgs) && imgs.length) u = imgs[0];
    else if (typeof imgs === 'string') u = imgs;
    if (!u) return null;
    return window.__ASSET__(u);
  };

  console.log('[config] mode=' + MODE + '  API=' + API_BASE);


/* ============================================================
   Rial → Toman helper
   ورودی‌ها به ریال، نمایش به تومان
   ============================================================ */
window.__rial2toman = function(rial){
  return Math.round((Number(rial) || 0) / 10);
};
window.__tomanLabel = function(rial){
  try{ return window.__rial2toman(rial).toLocaleString('fa-IR'); }
  catch(e){ return String(window.__rial2toman(rial)); }
};
})();
