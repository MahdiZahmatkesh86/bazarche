const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { protect, adminOnly } = require('../middleware/auth');

const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
if(!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive:true });

const ALLOWED = ['image/jpeg','image/png','image/webp','image/gif','image/avif'];
const MAX_SIZE = 5 * 1024 * 1024; /* 5MB */

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const ext = (path.extname(file.originalname) || '.jpg').toLowerCase().slice(0, 6);
    const id = crypto.randomBytes(12).toString('hex');
    cb(null, 'prod-' + Date.now() + '-' + id + ext);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: MAX_SIZE },
  fileFilter: (req, file, cb) => {
    if(ALLOWED.includes(file.mimetype)) return cb(null, true);
    cb(new Error('فرمت تصویر پشتیبانی نمی‌شود.'));
  }
});

/* POST /api/upload/product  — multiple images */
router.post('/product',
  protect, adminOnly,
  (req, res, next) => {
    upload.array('images', 10)(req, res, (err) => {
      if(err instanceof multer.MulterError){
        const msg = err.code === 'LIMIT_FILE_SIZE'
          ? 'حجم تصویر بیشتر از ۵ مگابایت است.'
          : err.message;
        return res.status(400).json({ success:false, message: msg });
      }
      if(err) return res.status(400).json({ success:false, message: err.message });
      next();
    });
  },
  (req, res) => {
    if(!req.files || !req.files.length){
      return res.status(400).json({ success:false, message:'هیچ فایلی ارسال نشد.' });
    }
    const urls = req.files.map(f => '/uploads/' + f.filename);
    res.json({ success:true, urls, files: req.files.map(f => ({ name:f.filename, size:f.size })) });
  }
);

/* POST /api/upload/product-single — one image */
router.post('/product-single',
  protect, adminOnly,
  (req, res, next) => {
    upload.single('image')(req, res, (err) => {
      if(err instanceof multer.MulterError){
        const msg = err.code === 'LIMIT_FILE_SIZE'
          ? 'حجم تصویر بیشتر از ۵ مگابایت است.'
          : err.message;
        return res.status(400).json({ success:false, message: msg });
      }
      if(err) return res.status(400).json({ success:false, message: err.message });
      next();
    });
  },
  (req, res) => {
    if(!req.file){
      return res.status(400).json({ success:false, message:'فایلی ارسال نشد.' });
    }
    res.json({ success:true, url:'/uploads/' + req.file.filename });
  }
);

/* DELETE /api/upload/delete — remove an uploaded file */
router.delete('/delete',
  protect, adminOnly,
  (req, res) => {
    try{
      const { url } = req.body || {};
      if(!url || !url.startsWith('/uploads/')) return res.status(400).json({ success:false });
      const filename = path.basename(url);
      const full = path.join(UPLOAD_DIR, filename);
      if(!full.startsWith(UPLOAD_DIR)) return res.status(400).json({ success:false, message:'مسیر نامعتبر' });
      if(fs.existsSync(full)) fs.unlinkSync(full);
      res.json({ success:true });
    }catch(e){
      res.status(500).json({ success:false, message:e.message });
    }
  }
);

module.exports = router;
