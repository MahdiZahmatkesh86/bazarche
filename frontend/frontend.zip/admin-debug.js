(function(){
  'use strict';
  if(window.__SAVE_DEBUG__) return;
  window.__SAVE_DEBUG__ = true;

  var _fetch = window.fetch.bind(window);

  window.fetch = function(input, init){
    var url = (typeof input === 'string') ? input : (input && input.url) || '';
    var isProdSave = /\/api\/products(\/\d+)?$/.test(url) && init && init.method && (init.method.toUpperCase() === 'PUT' || init.method.toUpperCase() === 'POST');
    var isUpload = /\/api\/upload\//.test(url);

    if(isProdSave){
      console.log('%c========== SAVE REQUEST ==========', 'color:#c81e3a;font-weight:bold');
      console.log('URL:', url);
      console.log('METHOD:', init.method);
      try{
        var body = JSON.parse(init.body);
        console.log('PAYLOAD:');
        console.log('  name:', body.name);
        console.log('  brand:', body.brand);
        console.log('  category:', body.category);
        console.log('  price:', body.price);
        console.log('  images count:', (body.images || []).length);
        console.log('  images:', body.images);
        console.log('  isActive:', body.isActive);
        console.log('FULL BODY:', body);
      }catch(e){
        console.log('  body parse error:', e.message);
        console.log('  raw body:', init.body);
      }
    }

    if(isUpload){
      console.log('%c[upload]', 'color:#0284c7', url);
    }

    return _fetch(input, init).then(function(res){
      if(isProdSave){
        var cloned = res.clone();
        cloned.text().then(function(text){
          console.log('%c========== SAVE RESPONSE ==========', 'color:#059669;font-weight:bold');
          console.log('  status:', res.status);
          console.log('  ok:', res.ok);
          console.log('  raw body:', text);
          try{
            var j = JSON.parse(text);
            if(j.product){
              console.log('  ✅ response.product.images:', j.product.images);
              console.log('  ✅ response.product.images count:', (j.product.images || []).length);
            }else{
              console.log('  ⚠ no product in response');
              console.log('  message:', j.message);
            }
          }catch(e){
            console.log('  parse error:', e.message);
          }
          console.log('%c==================================', 'color:#059669;font-weight:bold');
        });
      }
      if(isUpload && !res.ok){
        var c2 = res.clone();
        c2.text().then(function(t){ console.log('[upload] FAILED:', res.status, t); });
      }
      return res;
    });
  };

  console.log('%c[save-debug] ready — fetch wrapped', 'color:#c81e3a;font-weight:bold');
})();
