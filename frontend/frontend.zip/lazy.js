(function(){
  'use strict';
  if(!('IntersectionObserver' in window)) return;
  var obs = new IntersectionObserver(function(entries){
    entries.forEach(function(e){
      if(!e.isIntersecting) return;
      var img = e.target;
      if(img.dataset && img.dataset.src){
        img.src = img.dataset.src;
        delete img.dataset.src;
      }
      obs.unobserve(img);
    });
  }, { rootMargin: '200px' });
  function bind(){
    var list = document.querySelectorAll('img[data-src]');
    for(var i = 0; i < list.length; i++) obs.observe(list[i]);
  }
  window.__lazyBind = bind;
  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', bind);
  }else{ bind(); }
  var mo = new MutationObserver(function(){ bind(); });
  if(document.body) mo.observe(document.body, { childList: true, subtree: true });
})();
